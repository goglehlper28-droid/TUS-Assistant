package com.tus.assistant.voice

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Human-sounding speech from Gemini TTS (24 kHz, 16-bit mono PCM). Returns false on any problem so the caller can fall back. */
class NaturalVoice {
    private fun fetch(apiKey: String, model: String, voice: String, text: String): ByteArray? {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject()
                .put("text", "Say in a warm, natural, friendly human tone, like a real person talking: $text")))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        val conn = (URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true; connectTimeout = 10_000; readTimeout = 40_000
            setRequestProperty("Content-Type", "application/json"); setRequestProperty("x-goog-api-key", apiKey)
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            if (conn.responseCode != 200) return null
            val json = JSONObject(conn.inputStream.bufferedReader().readText())
            val parts = json.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
            for (i in 0 until parts.length()) {
                val d = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data").orEmpty()
                if (d.isNotEmpty()) return Base64.decode(d, Base64.DEFAULT)
            }
            return null
        } finally { conn.disconnect() }
    }

    suspend fun play(apiKey: String, model: String, voice: String, text: String): Boolean = withContext(Dispatchers.IO) {
        var track: AudioTrack? = null
        try {
            val pcm = fetch(apiKey, model, voice, text.take(900)) ?: return@withContext false
            if (pcm.size < 2000) return@withContext false
            track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(24000).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(pcm.size).setTransferMode(AudioTrack.MODE_STATIC).build()
            track.write(pcm, 0, pcm.size)
            track.play()
            val frames = pcm.size / 2
            val maxMs = frames * 1000L / 24000 + 2000
            var waited = 0L
            while (currentCoroutineContext().isActive && track.playbackHeadPosition < frames - 200 && waited < maxMs) { delay(60); waited += 60 }
            true
        } catch (e: kotlinx.coroutines.CancellationException) { throw e
        } catch (e: Exception) { false
        } finally { try { track?.stop() } catch (e: Exception) {}; track?.release() }
    }
}
