package com.tus.assistant

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tus.assistant.automation.Outcome
import com.tus.assistant.core.AssistantCore
import com.tus.assistant.core.Reply
import com.tus.assistant.ui.FaceState
import com.tus.assistant.ui.HoloFace
import com.tus.assistant.wakeword.WakeService
import com.tus.assistant.wakeword.WakeState
import kotlinx.coroutines.launch

data class Msg(val fromUser: Boolean, val text: String)

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    val core = AssistantCore(app)
    val store get() = core.store
    val messages = mutableStateListOf<Msg>()
    var busy by mutableStateOf(false)
    var speaking by mutableStateOf(false)
    var listening by mutableStateOf(false)
    var speakReplies by mutableStateOf(true)
    var pending by mutableStateOf<Outcome.Confirm?>(null)
    var linkStatus by mutableStateOf("")

    init { core.voice.onSpeakingChanged = { speaking = it } }

    val faceState: FaceState get() = when {
        speaking -> FaceState.SPEAKING; busy -> FaceState.THINKING; listening -> FaceState.LISTENING; else -> FaceState.IDLE
    }

    private fun say(text: String) { if (speakReplies) core.voice.speak(text.replace("⚠️", "").replace("🎤", ""), store.language) }

    fun send(text: String) {
        if (text.isBlank() || busy) return
        core.voice.stopSpeaking()
        messages += Msg(true, text); messages += Msg(false, "")
        val idx = messages.lastIndex
        busy = true
        viewModelScope.launch {
            when (val r = core.process(text) { messages[idx] = Msg(false, it) }) {
                is Reply.Text -> { messages[idx] = Msg(false, r.text); say(r.text) }
                is Reply.NeedsConfirm -> { messages[idx] = Msg(false, r.confirm.prompt); pending = r.confirm; say(r.confirm.prompt) }
            }
            busy = false
        }
    }

    fun confirm(pin: String) {
        val c = pending ?: return
        if (c.needsPin && !store.checkPin(pin)) { messages += Msg(false, "⚠️ Wrong PIN. Action cancelled."); pending = null; return }
        pending = null; busy = true
        viewModelScope.launch {
            val res = try { c.run() } catch (e: Exception) { "⚠️ ${e.message ?: "Failed."}" }
            messages += Msg(false, res); say(res); busy = false
        }
    }

    fun confirmBiometric() {
        val c = pending ?: return
        pending = null; busy = true
        viewModelScope.launch {
            val res = try { c.run() } catch (e: Exception) { "⚠️ ${e.message ?: "Failed."}" }
            messages += Msg(false, res); say(res); busy = false
        }
    }

    fun cancel() { pending = null; messages += Msg(false, "Cancelled.") }

    fun listen() {
        core.voice.stopSpeaking(); listening = true
        core.voice.listen(store.language,
            onText = { listening = false; send(it) },
            onFail = { listening = false; messages += Msg(false, "🎤 $it") })
    }

    fun pair(host: String, port: Int, code: String) {
        linkStatus = "Pairing…"
        viewModelScope.launch {
            linkStatus = try {
                val fp = core.remote.pair(host, port, code)
                "Paired ✅. Laptop fingerprint: ${fp.take(16)}… Check it matches the one on the laptop screen."
            } catch (e: Exception) { "Pairing failed: ${e.message}" }
        }
    }

    fun clear() { core.clear(); messages.clear(); core.voice.stopSpeaking() }
    override fun onCleared() { core.shutdown() }
}

class MainActivity : androidx.fragment.app.FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF29B6FF))) { TusScreen() } }
    }
    override fun onResume() { super.onResume(); WakeState.paused = true }
    override fun onPause() { super.onPause(); WakeState.paused = false }
}

private val Accent = Color(0xFF29B6FF)

@Composable
fun TusScreen(vm: ChatViewModel = viewModel()) {
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) vm.listen() }
    LaunchedEffect(vm.messages.size, vm.messages.lastOrNull()?.text) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.lastIndex)
    }
    Column(Modifier.fillMaxSize().background(Color(0xFF05070D)).statusBarsPadding().navigationBarsPadding().imePadding().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(when { vm.speaking -> "TUS • speaking"; vm.busy -> "TUS • thinking"; vm.listening -> "TUS • listening"; else -> "TUS • ready" },
                color = Accent, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings", tint = Color.White) }
        }
        HoloFace(vm.faceState, Modifier.fillMaxWidth().height(260.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.messages) { m ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    Surface(shape = RoundedCornerShape(16.dp), color = if (m.fromUser) Color(0xFF0B3A5B) else Color(0xFF111A28)) {
                        Text(m.text.ifEmpty { "…" }, color = Color.White, modifier = Modifier.padding(12.dp))
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Message TUS") }, maxLines = 3)
            IconButton(onClick = {
                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.listen()
                else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }) { Icon(Icons.Default.Mic, "Speak", tint = Accent) }
            IconButton(onClick = { vm.send(input); input = "" }) { Icon(Icons.Default.Send, "Send", tint = Accent) }
        }
    }
    vm.pending?.let { ConfirmDialog(it, vm) }
    if (showSettings) SettingsDialog(vm) { showSettings = false }
}

@Composable
fun ConfirmDialog(c: Outcome.Confirm, vm: ChatViewModel) {
    var pin by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    var act: android.content.Context = ctx
    while (act is android.content.ContextWrapper && act !is androidx.fragment.app.FragmentActivity) act = act.baseContext
    val fragAct = act as? androidx.fragment.app.FragmentActivity
    val canBio = fragAct != null && BiometricManager.from(ctx).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
    AlertDialog(onDismissRequest = { vm.cancel() }, title = { Text("Please confirm") },
        text = {
            Column {
                Text(c.prompt)
                if (canBio) TextButton(onClick = {
                    val prompt = BiometricPrompt(fragAct!!, ContextCompat.getMainExecutor(ctx), object : BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { vm.confirmBiometric() }
                    })
                    prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Confirm with your fingerprint")
                        .setNegativeButtonText("Cancel").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG).build())
                }) { Text("Use fingerprint") }
                if (c.needsPin) OutlinedTextField(pin, { pin = it.filter(Char::isDigit) }, label = { Text("PIN") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
            }
        },
        confirmButton = { TextButton(onClick = { vm.confirm(pin) }) { Text("Confirm") } },
        dismissButton = { TextButton(onClick = { vm.cancel() }) { Text("Cancel") } })
}

@Composable
fun SettingsDialog(vm: ChatViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val st = vm.store
    var key by remember { mutableStateOf(st.apiKey) }
    var model by remember { mutableStateOf(st.model) }
    var lang by remember { mutableStateOf(st.language) }
    var host by remember { mutableStateOf(st.remoteHost) }
    var port by remember { mutableStateOf(st.remotePort.toString()) }
    var code by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var wake by remember { mutableStateOf(st.wakeEnabled) }
    var pinMsg by remember { mutableStateOf(if (st.hasPin) "PIN is set." else "No PIN set.") }
    val mem = remember { mutableStateListOf<String>().apply { addAll(st.memories()) } }
    val notes = remember { mutableStateListOf<String>().apply { addAll(st.notes()) } }
    var natural by remember { mutableStateOf(st.naturalVoice) }
    var vname by remember { mutableStateOf(st.ttsVoice) }
    var tmodel by remember { mutableStateOf(st.ttsModel) }
    val treePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (e: Exception) {}
            st.filesTree = uri.toString()
        }
    }
    val phonePerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    fun startWake() {
        ContextCompat.startForegroundService(ctx, Intent(ctx, WakeService::class.java))
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.RECORD_AUDIO] == true || ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            st.wakeEnabled = true; wake = true; startWake()
        } else { wake = false }
    }

    AlertDialog(onDismissRequest = onClose, title = { Text("Settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("AI", color = Accent)
                OutlinedTextField(key, { key = it }, label = { Text("Gemini API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(model, { model = it }, label = { Text("Model") }, singleLine = true)
                OutlinedTextField(lang, { lang = it }, label = { Text("Speech language (auto, en-US, ur-PK, hi-IN, fa-IR, ps-AF)") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) { Switch(vm.speakReplies, { vm.speakReplies = it }); Spacer(Modifier.width(8.dp)); Text("Speak replies") }

                Text("Wake phrase (Hey TUS / Hey Commander / Hey Dost)", color = Accent)
                Text("Uses speech recognition in a loop, so it costs more battery than a true keyword engine. A notification shows while the mic is on.", style = MaterialTheme.typography.bodySmall)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(wake, { on ->
                        if (on) {
                            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
                            if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
                            permLauncher.launch(perms.toTypedArray())
                        } else { wake = false; st.wakeEnabled = false; ctx.startService(Intent(ctx, WakeService::class.java).setAction(WakeService.ACTION_STOP)) }
                    }); Spacer(Modifier.width(8.dp)); Text("Always listening")
                }
                TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("Battery: allow TUS to run in background") }
                TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))) }) { Text("Allow display over other apps (lets voice commands open apps)") }

                Text("Voice quality", color = Accent)
                Row(verticalAlignment = Alignment.CenterVertically) { Switch(natural, { natural = it }); Spacer(Modifier.width(8.dp)); Text("Natural human voice (Gemini)") }
                OutlinedTextField(vname, { vname = it }, label = { Text("Voice (Charon, Orus, Fenrir, Puck, Kore…)") }, singleLine = true)
                OutlinedTextField(tmodel, { tmodel = it }, label = { Text("Voice model") }, singleLine = true)

                Text("Phone permissions (for full control)", color = Accent)
                Text("Each one is optional and can be turned off in Android settings. If Android blocks a switch, open App info → ⋮ → Allow restricted settings, then try again.", style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { phonePerm.launch(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS)) }) { Text("Grant call, SMS and contacts") }
                TextButton(onClick = { treePicker.launch(null) }) { Text("Choose files folder (TUS can list, read, create, delete here)") }
                TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Enable screen control (Accessibility)") }
                TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) { Text("Allow reading notifications") }
                TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))) }) { Text("Open App info (Allow restricted settings)") }

                Text("Laptop link", color = Accent)
                Text("Install the TUS Windows agent, turn on Tailscale on both devices, click 'Pair new phone' on the laptop, then enter its address and code.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(host, { host = it }, label = { Text("Laptop address (Tailscale name or IP)") }, singleLine = true)
                OutlinedTextField(port, { port = it.filter(Char::isDigit) }, label = { Text("Port") }, singleLine = true)
                OutlinedTextField(code, { code = it.filter(Char::isDigit) }, label = { Text("Pairing code") }, singleLine = true)
                Row {
                    TextButton(onClick = { vm.pair(host, port.toIntOrNull() ?: 8443, code) }) { Text("Pair") }
                    TextButton(onClick = { vm.core.remote.unpair(); vm.linkStatus = "Unpaired on this phone." }) { Text("Unpair") }
                }
                if (vm.linkStatus.isNotEmpty()) Text(vm.linkStatus, style = MaterialTheme.typography.bodySmall)

                Text("Security", color = Accent)
                OutlinedTextField(pin, { pin = it.filter(Char::isDigit) }, label = { Text("New PIN (4–8 digits)") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                TextButton(onClick = { if (pin.length in 4..8) { st.setPin(pin); pin = ""; pinMsg = "PIN saved." } else pinMsg = "PIN must be 4–8 digits." }) { Text("Save PIN") }
                Text(pinMsg, style = MaterialTheme.typography.bodySmall)

                Text("Memory (what TUS remembers — edit or delete)", color = Accent)
                if (mem.isEmpty()) Text("Nothing saved. Say \"remember that …\".", style = MaterialTheme.typography.bodySmall)
                mem.forEachIndexed { i, m ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(m, { mem[i] = it }, Modifier.weight(1f))
                        TextButton(onClick = { mem.removeAt(i) }) { Text("Delete") }
                    }
                }
                Text("Notes", color = Accent)
                if (notes.isEmpty()) Text("No notes. Say \"note …\".", style = MaterialTheme.typography.bodySmall)
                notes.forEachIndexed { i, m ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(m, { notes[i] = it }, Modifier.weight(1f))
                        TextButton(onClick = { notes.removeAt(i) }) { Text("Delete") }
                    }
                }
                TextButton(onClick = { vm.clear() }) { Text("Clear conversation") }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                st.apiKey = key; st.model = model; st.language = lang; st.naturalVoice = natural; st.ttsVoice = vname; st.ttsModel = tmodel
                st.remoteHost = host.trim(); st.remotePort = port.toIntOrNull() ?: 8443
                st.saveMemories(mem.filter { it.isNotBlank() }); st.saveNotes(notes.filter { it.isNotBlank() })
                onClose()
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } })
}
