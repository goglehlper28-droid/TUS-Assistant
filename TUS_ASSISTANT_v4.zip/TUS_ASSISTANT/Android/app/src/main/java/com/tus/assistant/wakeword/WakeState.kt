package com.tus.assistant.wakeword

/** Shared flags so the screen and the background service don't use the microphone at the same time. */
object WakeState {
    @Volatile var paused = false   // true while the app screen is visible
    @Volatile var running = false
}
