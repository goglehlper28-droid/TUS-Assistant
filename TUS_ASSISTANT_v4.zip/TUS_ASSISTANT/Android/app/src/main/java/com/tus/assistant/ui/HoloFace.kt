package com.tus.assistant.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.*
import kotlin.random.Random

enum class FaceState { IDLE, LISTENING, THINKING, SPEAKING }

private val Blue = Color(0xFF29B6FF)
private val Cyan = Color(0xFF7DF3FF)

/** Stylised animated hologram head: blinking eyes, mouth that moves while speaking, HUD rings, particles. ~30 fps. */
@Composable
fun HoloFace(state: FaceState, modifier: Modifier = Modifier) {
    var t by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L; var acc = 0f
        while (true) withFrameNanos { n ->
            if (last != 0L) acc += (n - last) / 1e9f
            last = n
            if (acc >= 0.033f) { t += acc; acc = 0f }
        }
    }
    val particles = remember { List(36) { Triple(Random(it).nextFloat(), Random(it + 99).nextFloat(), 0.02f + Random(it + 7).nextFloat() * 0.05f) } }

    Canvas(modifier) {
        val w = size.width; val h = size.height
        val cx = w / 2; val cy = h / 2
        val s = min(w, h)
        val speed = when (state) { FaceState.THINKING -> 3.2f; FaceState.LISTENING -> 1.6f; FaceState.SPEAKING -> 1.4f; else -> 0.7f }

        drawCircle(Brush.radialGradient(listOf(Blue.copy(alpha = 0.28f), Color.Transparent), Offset(cx, cy), s * 0.55f), s * 0.55f, Offset(cx, cy))

        // HUD rings
        listOf(0.47f to 1f, 0.42f to -1.4f, 0.36f to 0.8f).forEachIndexed { i, (r, dir) ->
            val rad = s * r
            for (k in 0 until 4) {
                drawArc(Blue.copy(alpha = 0.55f - i * 0.12f), t * 40f * speed * dir + k * 90f, 48f - i * 8f, false,
                    Offset(cx - rad, cy - rad), Size(rad * 2, rad * 2), style = Stroke(width = 2.5f))
            }
        }

        // particles
        particles.forEach { (px, py, sp) ->
            val y = ((py - t * sp * speed) % 1f + 1f) % 1f
            drawCircle(Cyan.copy(alpha = 0.35f), 1.8f, Offset(px * w, y * h))
        }

        // head
        val a = s * 0.20f; val b = s * 0.29f
        val hy = cy
        drawOval(Blue.copy(alpha = 0.10f), Offset(cx - a, hy - b), Size(a * 2, b * 2))
        drawOval(Cyan.copy(alpha = 0.8f), Offset(cx - a, hy - b), Size(a * 2, b * 2), style = Stroke(2.5f))
        listOf(0.7f, 0.4f).forEach { f -> drawOval(Blue.copy(alpha = 0.22f), Offset(cx - a * f, hy - b), Size(a * 2 * f, b * 2), style = Stroke(1.2f)) }
        for (i in -9..9) {
            val q = i / 10f
            val x = a * sqrt(1 - q * q)
            drawLine(Blue.copy(alpha = 0.13f), Offset(cx - x, hy + b * q), Offset(cx + x, hy + b * q), 1f)
        }
        val scanY = hy - b + ((t * 0.35f) % 1f) * b * 2
        val sq = (scanY - hy) / b
        if (abs(sq) < 1f) { val x = a * sqrt(1 - sq * sq); drawLine(Cyan.copy(alpha = 0.6f), Offset(cx - x, scanY), Offset(cx + x, scanY), 2f) }

        // eyes
        val phase = t % 4.2f
        val blink = if (phase < 0.16f) abs(phase - 0.08f) / 0.08f else 1f
        val eyeScale = when (state) { FaceState.LISTENING -> 1.25f; FaceState.THINKING -> 0.7f; else -> 1f }
        val ew = a * 0.42f; val eh = a * 0.16f * blink * eyeScale + 1.5f
        val drift = if (state == FaceState.THINKING) sin(t * 2f) * a * 0.12f else 0f
        val ey = hy - b * 0.2f
        listOf(-1, 1).forEach { side ->
            val ex = cx + side * a * 0.48f + drift
            drawOval(Brush.radialGradient(listOf(Color.White, Cyan, Blue.copy(alpha = 0f)), Offset(ex, ey), ew),
                Offset(ex - ew, ey - eh * 1.4f), Size(ew * 2, eh * 2.8f))
            drawOval(Color.White, Offset(ex - ew * 0.45f, ey - eh * 0.5f), Size(ew * 0.9f, eh))
            val browLift = if (state == FaceState.LISTENING) a * 0.08f else 0f
            drawLine(Cyan.copy(alpha = 0.7f), Offset(ex - ew, ey - eh * 2.4f - browLift), Offset(ex + ew, ey - eh * 2.8f - browLift), 3f)
        }

        // nose
        drawLine(Blue.copy(alpha = 0.5f), Offset(cx, ey + eh), Offset(cx - a * 0.08f, hy + b * 0.18f), 2f)
        drawLine(Blue.copy(alpha = 0.5f), Offset(cx - a * 0.08f, hy + b * 0.18f), Offset(cx + a * 0.08f, hy + b * 0.18f), 2f)

        // mouth (open amount is a speech-like oscillation while speaking; Android TTS gives no audio levels)
        val my = hy + b * 0.52f; val mw = a * 0.5f
        val open = if (state == FaceState.SPEAKING) (0.25f + 0.75f * abs(sin(t * 9f) * sin(t * 5.3f + 1f))) * a * 0.22f else 0f
        if (open > 1f) {
            drawOval(Color(0xFF021522), Offset(cx - mw * 0.7f, my - open / 2), Size(mw * 1.4f, open))
            drawOval(Cyan, Offset(cx - mw * 0.7f, my - open / 2), Size(mw * 1.4f, open), style = Stroke(2.5f))
        } else {
            val p = Path().apply {
                moveTo(cx - mw, my); quadraticBezierTo(cx, my + a * 0.10f * (if (state == FaceState.IDLE) 1f else 0.4f), cx + mw, my)
            }
            drawPath(p, Cyan, style = Stroke(3f))
        }
    }
}
