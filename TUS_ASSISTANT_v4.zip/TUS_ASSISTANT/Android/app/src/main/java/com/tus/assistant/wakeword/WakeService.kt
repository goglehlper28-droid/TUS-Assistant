package com.tus.assistant.wakeword

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.tus.assistant.MainActivity
import com.tus.assistant.core.AssistantCore
import com.tus.assistant.core.Reply
import kotlinx.coroutines.*

/**
 * Always-listening foreground service. IMPORTANT: this detects the wake phrases by running Android's
 * speech recognizer in a loop and matching text. It is NOT an on-device keyword-spotting engine, so it
 * uses more battery and may beep on some phones. Replace listenLoop() with sherpa-onnx later for true wake words.
 */
class WakeService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var core: AssistantCore
    private var job: Job? = null
    private var wl: android.os.PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        core = AssistantCore(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        WakeState.running = true
        if (wl == null) wl = (getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "tus:wake").apply { acquire(10 * 60 * 60 * 1000L) }
        if (job?.isActive != true) job = scope.launch { listenLoop() }
        return START_STICKY
    }

    private suspend fun listenLoop() {
        while (currentCoroutineContext().isActive) {
            try {
                if (WakeState.paused) { delay(1000); continue }
                val heard = core.voice.listenOnce(core.store.language)
                if (heard == null) { delay(400); continue }
                val rest = afterWakePhrase(heard) ?: continue
                val lang = core.store.language
                val command = if (rest.isNotBlank()) rest else {
                    core.voice.speakAndWait("Yes?", lang)
                    core.voice.listenOnce(lang) ?: continue
                }
                respond(command, lang)
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) { delay(2000) } // recover from temporary mic/service problems
        }
    }

    private suspend fun respond(command: String, lang: String) {
        when (val r = core.process(command) {}) {
            is Reply.Text -> core.voice.speakAndWait(r.text.replace("⚠️", ""), lang)
            is Reply.NeedsConfirm -> {
                if (r.confirm.needsPin) { core.voice.speakAndWait("That needs your PIN. Please open the TUS app to confirm.", lang); return }
                core.voice.speakAndWait("${r.confirm.prompt} Say yes to confirm.", lang)
                val a = core.voice.listenOnce(lang)?.lowercase().orEmpty()
                if (listOf("yes", "yeah", "confirm", "haan", "han", "ji", "ہاں").any { a.contains(it) })
                    core.voice.speakAndWait(try { r.confirm.run() } catch (e: Exception) { "That failed." }, lang)
                else core.voice.speakAndWait("Okay, cancelled.", lang)
            }
        }
    }

    private fun afterWakePhrase(heard: String): String? {
        val h = heard.lowercase().trim()
        val phrases = listOf("hey tus", "hay tus", "hey tuss", "hi tus", "hey commander", "hey dost", "hey doost", "hey dosth")
        for (p in phrases) { val i = h.indexOf(p); if (i >= 0) return h.substring(i + p.length).trim(' ', ',') }
        return null
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "TUS listening", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, WakeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("TUS is listening for \"Hey TUS\"")
            .setContentText("Microphone is active. Tap Stop to turn off.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open).setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .build()
    }

    override fun onDestroy() {
        WakeState.running = false
        try { wl?.release() } catch (e: Exception) {}
        job?.cancel(); scope.cancel(); core.shutdown()
        super.onDestroy()
    }

    companion object { const val CHANNEL = "tus_listen"; const val ACTION_STOP = "com.tus.assistant.STOP" }
}
