package com.tus.assistant.automation

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import androidx.documentfile.provider.DocumentFile
import com.tus.assistant.remote.RemoteClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import com.tus.assistant.security.SecureStore
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date

sealed class Outcome {
    data class Done(val text: String) : Outcome()
    data class Confirm(val prompt: String, val needsPin: Boolean, val run: suspend () -> String) : Outcome()
    object NotHandled : Outcome()
}

/** Voice/text commands for the phone and the laptop. Uses official Android APIs; sensitive actions ask first. */
class Automation(private val ctx: Context, private val store: SecureStore, private val remote: RemoteClient) {

    suspend fun handle(raw: String): Outcome {
        val rawT = raw.trim().trimEnd('.', '!', '?')
        var t = rawT.lowercase()
        t = t.replace("kholo", "open").replace("khol do", "open").replace("kholna", "open")
            .replace("peeche jao", "go back").replace("wapis jao", "go back")
            .replace("home par jao", "go home").replace("home pe jao", "go home")
        val laptopWords = listOf("laptop", "computer", " pc", "لیپ", "کمپیوٹر")
        if (laptopWords.any { t.contains(it) } && !t.startsWith("remember")) return laptop(t, rawT)
        screen(t, rawT)?.let { return it }

        Regex("^(remember|yaad rakho)( that)? (.+)").find(t)?.let {
            val l = store.memories(); l.add(rawT.takeLast(it.groupValues[3].length)); store.saveMemories(l)
            return Outcome.Done("Got it, I'll remember that. You can view or delete it in Settings → Memory.")
        }
        Regex("^(take a note|make a note|create a note|note down|note)( that|:)? (.+)").find(t)?.let {
            val l = store.notes(); l.add(rawT.takeLast(it.groupValues[3].length)); store.saveNotes(l)
            return Outcome.Done("Note saved.")
        }
        if (Regex("what('?s| is)? the time|current time|time kya|time batao").containsMatchIn(t))
            return Outcome.Done("It's ${DateFormat.getTimeInstance(DateFormat.SHORT).format(Date())}.")
        if (Regex("(today'?s|the|current) date|what day").containsMatchIn(t))
            return Outcome.Done("Today is ${DateFormat.getDateInstance(DateFormat.FULL).format(Date())}.")
        if (t.contains("battery") && !t.startsWith("open")) return Outcome.Done(battery())
        if (Regex("(internet|wifi|wi-fi|network|connection) status|am i connected|am i online").containsMatchIn(t)) return Outcome.Done(connectivity())

        files(t, rawT)?.let { return it }
        Regex("^(call|dial|phone) (.+)$").find(t)?.let { return call(it.groupValues[2].trim()) }
        Regex("^(send )?(sms|text|message) (to )?(.+?) (saying|say|that) (.+)$").find(t)?.let {
            return sms(it.groupValues[4].trim(), rawT.takeLast(it.groupValues[6].length))
        }
        Regex("^(whatsapp|share on whatsapp|send on whatsapp) (.+)").find(t)?.let {
            val body = rawT.takeLast(it.groupValues[2].length)
            return Outcome.Confirm("Share \"$body\" on WhatsApp?", false) {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, body).setPackage("com.whatsapp")
                if (i.resolveActivity(ctx.packageManager) == null) "WhatsApp isn't installed." else { start(i); "WhatsApp is open, pick a chat." }
            }
        }
        Regex("remind me (?:to )?(.+?) in (\\d+) ?(minute|min|hour|hr)s?").find(t)?.let {
            val secs = it.groupValues[2].toInt() * if (it.groupValues[3].startsWith("h")) 3600 else 60
            start(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs)
                .putExtra(AlarmClock.EXTRA_MESSAGE, it.groupValues[1]).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return Outcome.Done("Reminder timer set for ${it.groupValues[2]} ${it.groupValues[3]}(s): ${it.groupValues[1]}.")
        }
        media(t)?.let { return Outcome.Done(it) }
        Regex("^open (.+)").find(t)?.let { return Outcome.Done(open(it.groupValues[1].trim())) }
        Regex("^(search|google) (for )?(.+)").find(t)?.let {
            start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(it.groupValues[3]))))
            return Outcome.Done("Searching for ${it.groupValues[3]}.")
        }
        Regex("^(play|search) (.+) on youtube").find(t)?.let {
            start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(it.groupValues[2]))))
            return Outcome.Done("Searching YouTube for ${it.groupValues[2]}.")
        }
        return Outcome.NotHandled
    }

    // ---------- phone screen control, notifications, device controls ----------
    private fun screen(t: String, rawT: String): Outcome? {
        fun a11y(block: (TusAccessibilityService) -> String): Outcome =
            TusAccessibilityService.instance?.let { Outcome.Done(block(it)) }
                ?: Outcome.Done("Screen control is off. Open TUS Settings → Phone permissions → Enable screen control, then switch on TUS Assistant.")
        fun orig(m: MatchResult, i: Int) = rawT.substring(m.groups[i]!!.range)

        Regex("^(click on|tap on|click|tap) (.+)$").find(t)?.let { m -> return a11y { it.clickText(orig(m, 2)) } }
        Regex("^type (.+)$").find(t)?.let { m -> return a11y { it.typeText(orig(m, 1)) } }
        return when {
            t == "back" || t == "go back" -> a11y { it.global(AccessibilityService.GLOBAL_ACTION_BACK); "Went back." }
            t in listOf("home", "go home", "home screen", "go to home screen", "go to home") -> a11y { it.global(AccessibilityService.GLOBAL_ACTION_HOME); "Home." }
            t in listOf("recents", "recent apps", "show recent apps", "open recents") -> a11y { it.global(AccessibilityService.GLOBAL_ACTION_RECENTS); "Showing recent apps." }
            t in listOf("open notifications", "show notifications", "pull down notifications") -> a11y { it.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); "Notifications are open." }
            Regex("^(take (a )?)?screenshot$").matches(t) -> a11y {
                if (Build.VERSION.SDK_INT >= 28) { it.global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT); "Screenshot taken." } else "Screenshots by voice need Android 9 or newer." }
            Regex("^lock (the )?(screen|phone)$").matches(t) -> a11y {
                if (Build.VERSION.SDK_INT >= 28) { it.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN); "Locked." } else "Locking by voice needs Android 9 or newer." }
            Regex("^scroll (up|down)$").matches(t) -> a11y { it.scroll(t.endsWith("down")) }
            Regex("^(read (the )?screen|what'?s on (the )?screen|read what'?s on screen)$").matches(t) -> a11y { it.readScreen() }
            Regex("^(read )?(my )?notifications$").matches(t) -> {
                val svc = TusNotificationService.instance
                if (svc == null) Outcome.Done("Notification access is off. Open TUS Settings → Phone permissions → Allow reading notifications.")
                else Outcome.Done(svc.summary())
            }
            t == "clear notifications" -> TusNotificationService.instance?.let { Outcome.Done(it.clearAll()) }
                ?: Outcome.Done("Notification access is off. Open TUS Settings → Phone permissions → Allow reading notifications.")
            Regex("^(turn )?(on|off) (the )?(flashlight|torch)$").matches(t) -> Outcome.Done(torch(t.contains(" on ")))
            Regex("^(flashlight|torch) (on|off)$").matches(t) -> Outcome.Done(torch(t.endsWith("on")))
            t == "volume up" || t == "volume down" || t == "mute" || t == "unmute" -> {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val dir = when (t) { "volume up" -> AudioManager.ADJUST_RAISE; "volume down" -> AudioManager.ADJUST_LOWER; "mute" -> AudioManager.ADJUST_MUTE; else -> AudioManager.ADJUST_UNMUTE }
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI); Outcome.Done("Done.")
            }
            Regex("^set volume (to )?(\\d{1,3})( percent|%)?$").find(t) != null -> {
                val pct = Regex("(\\d{1,3})").find(t)!!.value.toInt().coerceIn(0, 100)
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * pct / 100, AudioManager.FLAG_SHOW_UI)
                Outcome.Done("Volume set to $pct%.")
            }
            else -> null
        }
    }

    private fun torch(on: Boolean): String = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        if (id == null) "This phone has no flashlight." else { cm.setTorchMode(id, on); if (on) "Flashlight on." else "Flashlight off." }
    } catch (e: Exception) { "I couldn't control the flashlight." }

    // ---------- files in a folder you choose (Storage Access Framework) ----------
    private fun filesRoot(): DocumentFile? {
        val u = store.filesTree
        if (u.isBlank()) return null
        return try { DocumentFile.fromTreeUri(ctx, Uri.parse(u)) } catch (e: Exception) { null }
    }

    private fun findFile(dir: DocumentFile, q: String, depth: Int = 0): DocumentFile? {
        for (f in dir.listFiles()) {
            if (f.isFile && f.name?.contains(q, true) == true) return f
            if (f.isDirectory && depth < 3) findFile(f, q, depth + 1)?.let { return it }
        }
        return null
    }

    private fun files(t: String, rawT: String): Outcome? {
        if (!Regex("^(list|show) (my )?files$|^(find|search) file |^read file |^create file |^delete file ").containsMatchIn(t)) return null
        val root = filesRoot() ?: return Outcome.Done("Choose a folder first: Settings → Phone permissions → Choose files folder.")
        fun orig(m: MatchResult, i: Int) = rawT.substring(m.groups[i]!!.range)
        Regex("^(list|show) (my )?files$").find(t)?.let {
            val names = root.listFiles().mapNotNull { f -> f.name }.take(15)
            return Outcome.Done(if (names.isEmpty()) "That folder is empty." else "Files: " + names.joinToString(", ") + ".")
        }
        Regex("^(find|search) file (.+)$").find(t)?.let { m ->
            val f = findFile(root, orig(m, 2)); return Outcome.Done(if (f == null) "No file matches that." else "Found ${f.name}.")
        }
        Regex("^read file (.+)$").find(t)?.let { m ->
            val f = findFile(root, orig(m, 1)) ?: return Outcome.Done("No file matches that.")
            val name = f.name ?: ""
            if (!(f.type?.startsWith("text") == true || Regex("\\.(txt|md|csv|json|log)$", RegexOption.IGNORE_CASE).containsMatchIn(name)))
                return Outcome.Done("I can only read text files.")
            val txt = ctx.contentResolver.openInputStream(f.uri)?.bufferedReader()?.use { it.readText().take(800) } ?: ""
            return Outcome.Done(if (txt.isBlank()) "$name is empty." else "$name says: $txt")
        }
        Regex("^create file (.+?) (with|saying|containing) (.+)$").find(t)?.let { m ->
            val base = orig(m, 1).removeSuffix(".txt"); val content = orig(m, 3)
            return Outcome.Confirm("Create the file \"$base.txt\" in your chosen folder?", false) {
                val f = root.createFile("text/plain", base)
                if (f == null) "I couldn't create the file." else { ctx.contentResolver.openOutputStream(f.uri)?.use { it.write(content.toByteArray()) }; "Created ${f.name}." }
            }
        }
        Regex("^delete file (.+)$").find(t)?.let { m ->
            val f = findFile(root, orig(m, 1)) ?: return Outcome.Done("No file matches that.")
            return Outcome.Confirm("Delete \"${f.name}\" permanently?", false) { if (f.delete()) "Deleted." else "I couldn't delete it." }
        }
        return null
    }

    // ---------- Wake-on-LAN ----------
    private suspend fun wakeLaptop(): String = withContext(Dispatchers.IO) {
        val parts = store.laptopMac.split(":", "-").filter { it.isNotBlank() }
        if (parts.size != 6) return@withContext "I don't have your laptop's MAC address yet. Pair with the laptop once, then try again."
        try {
            val mac = parts.map { it.toInt(16).toByte() }.toByteArray()
            val payload = ByteArray(6) { 0xFF.toByte() } + ByteArray(96) { mac[it % 6] }
            DatagramSocket().use { s ->
                s.broadcast = true
                s.send(DatagramPacket(payload, payload.size, InetAddress.getByName("255.255.255.255"), 9))
            }
            "I sent the wake-up signal. This only works if you're on the same Wi-Fi as the laptop and its network card is set up for Wake-on-LAN."
        } catch (e: Exception) { "I couldn't send the wake-up signal: ${e.message}" }
    }

    // ---------- calls and SMS ----------
    private fun granted(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun findNumber(name: String): String? {
        if (Regex("^[+0-9 \\-]{5,}$").matches(name)) return name.replace(" ", "").replace("-", "")
        if (!granted(Manifest.permission.READ_CONTACTS)) return null
        val p = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        ctx.contentResolver.query(p, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return null
    }

    private fun call(target: String): Outcome {
        val num = findNumber(target)
        if (num == null) return Outcome.Done(
            if (!granted(Manifest.permission.READ_CONTACTS) && !Regex("^[+0-9 \\-]{5,}$").matches(target))
                "I need contacts permission to find \"$target\". Open Settings → Phone permissions → Grant call, SMS and contacts."
            else "I couldn't find \"$target\" in your contacts.")
        return Outcome.Confirm("Call $target ($num)?", false) {
            if (granted(Manifest.permission.CALL_PHONE)) { start(Intent(Intent.ACTION_CALL, Uri.parse("tel:$num"))); "Calling $target." }
            else { start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num"))); "Opening the dialer for $target." }
        }
    }

    @Suppress("DEPRECATION")
    private fun sms(target: String, body: String): Outcome {
        val num = findNumber(target) ?: return Outcome.Done(
            if (!granted(Manifest.permission.READ_CONTACTS) && !Regex("^[+0-9 \\-]{5,}$").matches(target))
                "I need contacts permission to find \"$target\". Open Settings → Phone permissions → Grant call, SMS and contacts."
            else "I couldn't find \"$target\" in your contacts.")
        return Outcome.Confirm("Send this text to $target: \"$body\"?", false) {
            if (granted(Manifest.permission.SEND_SMS)) {
                val sm = SmsManager.getDefault(); sm.sendMultipartTextMessage(num, null, sm.divideMessage(body), null, null); "Message sent to $target."
            } else {
                start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).putExtra("sms_body", body)); "Message ready. Press send in your messaging app."
            }
        }
    }

    // ---------- laptop ----------
    private suspend fun laptop(t: String, rawT: String): Outcome {
        if (!remote.isPaired()) return Outcome.Done("Your laptop isn't paired yet. Install the TUS Windows agent, then open Settings → Laptop link and pair with the code shown on the laptop.")
        suspend fun cmd(a: String, args: JSONObject = JSONObject()) = Outcome.Done(remote.command(a, args).message)
        fun sensitive(prompt: String, a: String, args: JSONObject = JSONObject()): Outcome =
            if (!store.hasPin) Outcome.Done("Set a PIN in Settings → Security first. This action needs your PIN.")
            else Outcome.Confirm("$prompt Enter your PIN.", true) { remote.command(a, args).message }
        val tail = "(?: (?:on|in|into|from))? (?:my |the )?(?:home )?(?:laptop|computer|pc)"
        fun orig(m: MatchResult, i: Int) = rawT.substring(m.groups[i]!!.range)

        if (Regex("\\bunlock\\b").containsMatchIn(t)) return Outcome.Done("For safety I can't unlock your laptop. Please unlock it yourself.")
        if (Regex("\\bwake\\b|power on|turn on|boot up|on kar").containsMatchIn(t)) return Outcome.Done(wakeLaptop())
        if (Regex("shut ?down|power off|turn off").containsMatchIn(t)) return sensitive("Shut down your laptop in 30 seconds?", "power", JSONObject().put("mode", "shutdown"))
        if (Regex("restart|reboot").containsMatchIn(t)) return sensitive("Restart your laptop in 30 seconds?", "power", JSONObject().put("mode", "restart"))
        if (Regex("cancel (the )?(shutdown|restart)").containsMatchIn(t)) return cmd("power", JSONObject().put("mode", "cancel"))
        if (Regex("\\bsleep\\b").containsMatchIn(t)) return sensitive("Put your laptop to sleep?", "power", JSONObject().put("mode", "sleep"))
        if (Regex("\\block\\b").containsMatchIn(t)) return sensitive("Lock your laptop?", "lock")
        if (t.contains("notepad")) return cmd("open_notepad")
        if (t.contains("calculator") || t.contains("calc")) return cmd("open_calculator")
        if (Regex("explorer|file manager").containsMatchIn(t)) return cmd("open_explorer")

        Regex("^(type|write) (.+?)$tail$").find(t)?.let { return cmd("type_text", JSONObject().put("text", orig(it, 2))) }
        Regex("^press (.+?)$tail$").find(t)?.let {
            val keys = it.groupValues[1].split(Regex("[ +]| plus ")).filter { k -> k.isNotBlank() }
            return cmd("hotkey", JSONObject().put("keys", org.json.JSONArray(keys)))
        }
        Regex("^(double |right |left )?click( on)?$tail$|^(double |right |left )?click$").find(t)?.let {
            val w = (it.groupValues[1].ifEmpty { it.groupValues[3] }).trim()
            return cmd("mouse_click", JSONObject().put("button", if (w == "right") "right" else "left").put("double", w == "double"))
        }
        Regex("^move (the )?mouse (up|down|left|right)( (\\d+))?").find(t)?.let {
            return cmd("mouse_move", JSONObject().put("direction", it.groupValues[2]).put("amount", it.groupValues[4].ifEmpty { "150" }.toInt()))
        }
        Regex("volume (up|down)|\\bmute\\b|unmute").find(t)?.let {
            val d = if (it.value.contains("up")) "up" else if (it.value.contains("down")) "down" else "mute"
            return cmd("volume", JSONObject().put("dir", d).put("steps", 5))
        }
        Regex("(pause|play|resume|next|previous) (the )?(music|song|video|track|media)").find(t)?.let {
            val k = when (it.groupValues[1]) { "next" -> "next"; "previous" -> "previous"; else -> "play_pause" }
            return cmd("media", JSONObject().put("key", k))
        }
        Regex("^(search|find|look for) (files? )?(for )?(.+?)$tail$").find(t)?.let { return cmd("search_files", JSONObject().put("query", orig(it, 4))) }
        Regex("^run (the )?(script )?(.+?)$tail$").find(t)?.let { return sensitive("Run the script \"${orig(it, 3)}\" on your laptop?", "run_script", JSONObject().put("name", orig(it, 3))) }
        Regex("note (.+)").find(t)?.let { return cmd("create_note", JSONObject().put("text", orig(it, 1).let { s -> s })) }

        val site = Regex("([a-z0-9-]+\\.(com|org|net|pk|io|co|app|dev)(/\\S*)?)").find(t)?.groupValues?.get(1)
            ?: when {
                t.contains("youtube") -> "youtube.com"
                t.contains("google") || Regex("browser|chrome|edge|firefox|internet|website|\\bweb\\b").containsMatchIn(t) -> "google.com"
                else -> null
            }
        if (site != null) return cmd("open_url", JSONObject().put("url", "https://$site"))
        Regex("^(open|start|launch) (.+?)$tail$").find(t)?.let { return cmd("launch_app", JSONObject().put("name", orig(it, 2))) }
        if (Regex("status|check|online|battery|alive|how is|is my").containsMatchIn(t)) return cmd("status")
        return Outcome.Done("On your laptop I can check status, lock it, shut down or restart (PIN), open any app, a browser or website, type text, press keys, click, move the mouse, change volume, control media, find files, run your approved scripts, or save a note. I can't do that one yet.")
    }

    // ---------- helpers ----------
    private fun start(i: Intent) { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    private fun open(target: String): String {
        val settings = mapOf(
            "wifi settings" to Settings.ACTION_WIFI_SETTINGS, "wi-fi settings" to Settings.ACTION_WIFI_SETTINGS,
            "bluetooth settings" to Settings.ACTION_BLUETOOTH_SETTINGS, "bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
            "display settings" to Settings.ACTION_DISPLAY_SETTINGS, "sound settings" to Settings.ACTION_SOUND_SETTINGS,
            "battery settings" to Settings.ACTION_BATTERY_SAVER_SETTINGS, "settings" to Settings.ACTION_SETTINGS
        )
        settings[target]?.let { start(Intent(it)); return "Opening $target." }
        if (target.contains(".") && !target.contains(" ")) {
            start(Intent(Intent.ACTION_VIEW, Uri.parse(if (target.startsWith("http")) target else "https://$target"))); return "Opening $target."
        }
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().equals(target, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(target, true) }
        if (match != null) {
            pm.getLaunchIntentForPackage(match.activityInfo.packageName)?.let { start(it); return "Opening ${match.loadLabel(pm)}." }
        }
        if (target == "youtube") { start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))); return "Opening YouTube in the browser." }
        return "I couldn't find an app called \"$target\" on this phone."
    }

    private fun media(t: String): String? {
        val key = when {
            Regex("^(pause|stop) (the )?(music|song|media|video)").containsMatchIn(t) -> KeyEvent.KEYCODE_MEDIA_PAUSE
            Regex("^(play|resume) (the )?(music|song|media)$").containsMatchIn(t) -> KeyEvent.KEYCODE_MEDIA_PLAY
            Regex("^next (song|track)").containsMatchIn(t) -> KeyEvent.KEYCODE_MEDIA_NEXT
            Regex("^(previous|last) (song|track)").containsMatchIn(t) -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return null
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
        return "Done."
    }

    private fun battery(): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return "I can't read the battery right now."
        val pct = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) * 100 / i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        return "Battery is at $pct%${if (charging) " and charging" else ""}."
    }

    private fun connectivity(): String {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "You're offline."
        val kind = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            else -> "a network"
        }
        return "You're online via $kind."
    }
}
