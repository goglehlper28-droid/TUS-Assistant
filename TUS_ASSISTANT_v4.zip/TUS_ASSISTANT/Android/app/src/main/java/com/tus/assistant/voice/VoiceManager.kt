package com.tus.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.tus.assistant.security.SecureStore
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.Locale
import kotlin.coroutines.resume

/** Speech in/out. Speaks with Gemini's natural voice when enabled, otherwise Android's built-in voice. Main thread only. */
class VoiceManager(private val context: Context, private val store: SecureStore? = null) {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var waiter: CompletableDeferred<Unit>? = null
    private val natural = NaturalVoice()
    private val speechScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val speakLock = Mutex()

    var onSpeakingChanged: (Boolean) -> Unit = {}

    init {
        tts = TextToSpeech(context) { status -> ttsReady = status == TextToSpeech.SUCCESS }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { onSpeakingChanged(true) }
            override fun onDone(id: String?) { onSpeakingChanged(false); waiter?.complete(Unit) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { onSpeakingChanged(false); waiter?.complete(Unit) }
        })
    }

    private suspend fun speakNow(text: String, languageTag: String) {
        val clean = text.replace(Regex("[*_#`]"), "").trim()
        if (clean.isEmpty()) return
        val lang = if (languageTag == "auto") detectLang(clean) else languageTag
        val st = store
        if (st != null && st.naturalVoice && st.apiKey.isNotBlank()) {
            onSpeakingChanged(true)
            val ok = try { natural.play(st.apiKey, st.ttsModel, st.ttsVoice, clean) } finally { onSpeakingChanged(false) }
            if (ok) return
        }
        if (!ttsReady) return
        waiter = CompletableDeferred()
        tts?.language = Locale.forLanguageTag(lang)
        tts?.speak(clean.take(3500), TextToSpeech.QUEUE_FLUSH, null, "tus-${System.nanoTime()}")
        withTimeoutOrNull(60_000) { waiter?.await() }
    }

    private fun detectLang(s: String): String {
        val arabic = s.count { it.code in 0x0600..0x06FF }
        val deva = s.count { it.code in 0x0900..0x097F }
        return when { arabic > 2 -> "ur-PK"; deva > 2 -> "hi-IN"; else -> "en-US" }
    }

    fun speak(text: String, languageTag: String, flush: Boolean = false) {
        if (flush) stopSpeaking()
        speechScope.launch { speakLock.withLock { speakNow(text, languageTag) } }
    }

    /** Speaks and suspends until finished, so the microphone doesn't hear TUS itself. */
    suspend fun speakAndWait(text: String, languageTag: String) {
        stopSpeaking()
        speakLock.withLock { speakNow(text, languageTag) }
    }

    fun stopSpeaking() {
        speechScope.coroutineContext.cancelChildren()
        tts?.stop(); waiter?.complete(Unit); onSpeakingChanged(false)
    }

    fun listen(languageTag: String, onText: (String) -> Unit, onFail: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onFail("Speech recognition isn't available on this device."); return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) onFail("I didn't catch that.") else onText(text)
            }
            override fun onError(error: Int) {
                onFail(when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't hear anything."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is needed."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network problem during recognition."
                    else -> "Speech recognition error ($error)."
                })
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        recognizer = r
        val tag = if (languageTag == "auto") Locale.getDefault().toLanguageTag() else languageTag
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
        })
    }

    suspend fun listenOnce(languageTag: String): String? = suspendCancellableCoroutine { cont ->
        listen(languageTag, onText = { if (cont.isActive) cont.resume(it) }, onFail = { if (cont.isActive) cont.resume(null) })
        cont.invokeOnCancellation { recognizer?.cancel() }
    }

    fun cancelListening() { recognizer?.cancel() }
    fun shutdown() { speechScope.cancel(); recognizer?.destroy(); tts?.shutdown() }
}
