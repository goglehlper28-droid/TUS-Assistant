package com.tus.assistant.automation

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Official Android Accessibility API. Only acts when the user asks TUS to; the user must switch it on in Settings. */
class TusAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: TusAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun global(action: Int): Boolean = performGlobalAction(action)

    fun clickText(text: String): String {
        val root = rootInActiveWindow ?: return "I can't see the screen right now."
        for (n in root.findAccessibilityNodeInfosByText(text)) {
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "Tapped \"$text\"."
        }
        return "I couldn't find \"$text\" on the screen."
    }

    fun typeText(text: String): String {
        val root = rootInActiveWindow ?: return "I can't see the screen right now."
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "Tap a text box first, then ask me to type."
        val old = if (f.isShowingHintText) "" else (f.text?.toString() ?: "")
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, old + text) }
        return if (f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "Typed it." else "That field didn't accept text."
    }

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) findScrollable(n.getChild(i))?.let { return it }
        return null
    }

    fun scroll(down: Boolean): String {
        val s = findScrollable(rootInActiveWindow) ?: return "Nothing to scroll here."
        s.performAction(if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
        return "Scrolled ${if (down) "down" else "up"}."
    }

    fun readScreen(): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || sb.length > 1200) return
            val t = n.text?.toString() ?: n.contentDescription?.toString()
            if (!t.isNullOrBlank()) sb.append(t.trim()).append(". ")
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        return if (sb.isEmpty()) "I can't find any readable text on the screen." else sb.toString().take(1200)
    }
}
