package com.tus.assistant.automation

import android.app.Notification
import android.service.notification.NotificationListenerService

/** Lets TUS read your current notifications when you ask. Switched on by you in Android settings. */
class TusNotificationService : NotificationListenerService() {
    companion object { @Volatile var instance: TusNotificationService? = null }

    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { instance = null }

    fun summary(): String {
        val list = try { activeNotifications.toList() } catch (e: Exception) { emptyList() }
            .filter { it.packageName != packageName && it.isClearable }
        if (list.isEmpty()) return "You have no notifications."
        return "You have ${list.size} notifications. " + list.take(6).joinToString(" ") { sbn ->
            val e = sbn.notification.extras
            val app = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString() } catch (ex: Exception) { sbn.packageName }
            val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val text = e.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            "$app: $title $text."
        }
    }

    fun clearAll(): String { cancelAllNotifications(); return "Notifications cleared." }
}
