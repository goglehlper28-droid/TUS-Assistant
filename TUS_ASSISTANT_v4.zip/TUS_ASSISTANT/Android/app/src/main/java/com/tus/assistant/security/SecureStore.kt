package com.tus.assistant.security

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID

/** Encrypted storage (Android Keystore backed). Nothing secret is hardcoded. */
class SecureStore(context: Context) {
    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context, "tus_secure_prefs",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private fun s(k: String, d: String = "") = prefs.getString(k, d) ?: d
    private fun put(k: String, v: String) = prefs.edit().putString(k, v).apply()

    var apiKey: String get() = s("gemini_key"); set(v) = put("gemini_key", v.trim())
    var model: String get() = s("model", "gemini-flash-latest"); set(v) = put("model", v.trim())
    var naturalVoice: Boolean get() = prefs.getBoolean("natural", true); set(v) = prefs.edit().putBoolean("natural", v).apply()
    var ttsVoice: String get() = s("tts_voice", "Charon"); set(v) = put("tts_voice", v.trim())
    var ttsModel: String get() = s("tts_model", "gemini-3.1-flash-tts-preview"); set(v) = put("tts_model", v.trim())
    /** BCP-47 tag for speech, e.g. en-US, ur-PK, hi-IN, fa-IR, ps-AF. */
    var language: String get() = s("lang", "en-US"); set(v) = put("lang", v.trim())
    var wakeEnabled: Boolean get() = prefs.getBoolean("wake", false); set(v) = prefs.edit().putBoolean("wake", v).apply()

    var filesTree: String get() = s("files_tree"); set(v) = put("files_tree", v)
    var laptopMac: String get() = s("laptop_mac"); set(v) = put("laptop_mac", v)

    // ---- Laptop link ----
    var remoteHost: String get() = s("r_host"); set(v) = put("r_host", v.trim())
    var remotePort: Int get() = s("r_port", "8443").toIntOrNull() ?: 8443; set(v) = put("r_port", v.toString())
    var remoteSecret: String get() = s("r_secret"); set(v) = put("r_secret", v)
    var remoteFingerprint: String get() = s("r_fp"); set(v) = put("r_fp", v)
    val deviceId: String get() = s("dev_id").ifEmpty { UUID.randomUUID().toString().also { put("dev_id", it) } }

    // ---- PIN (salted SHA-256; stored inside encrypted prefs) ----
    val hasPin: Boolean get() = s("pin_hash").isNotEmpty()
    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        put("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
        put("pin_hash", hash(salt, pin))
    }
    fun checkPin(pin: String): Boolean {
        if (!hasPin) return false
        val salt = Base64.decode(s("pin_salt"), Base64.NO_WRAP)
        return MessageDigest.isEqual(hash(salt, pin).toByteArray(), s("pin_hash").toByteArray())
    }
    private fun hash(salt: ByteArray, pin: String): String =
        MessageDigest.getInstance("SHA-256").digest(salt + pin.toByteArray()).joinToString("") { "%02x".format(it) }

    // ---- User-controlled memory and notes (view / edit / delete in the app) ----
    fun memories(): MutableList<String> = readList("memories")
    fun saveMemories(l: List<String>) = writeList("memories", l)
    fun notes(): MutableList<String> = readList("notes")
    fun saveNotes(l: List<String>) = writeList("notes", l)
    private fun readList(k: String): MutableList<String> {
        val a = try { JSONArray(s(k, "[]")) } catch (e: Exception) { JSONArray() }
        return MutableList(a.length()) { a.getString(it) }
    }
    private fun writeList(k: String, l: List<String>) = put(k, JSONArray(l).toString())
}
