# TUS Assistant — Phase 1 (Android core)

## What works in this phase
- Chat with Gemini (streaming), with conversation context
- API key stored encrypted on-device (Android Keystore); never in source code
- Voice input (Android speech recognition) and spoken replies (Android TTS)
- Clear error messages for missing key, bad key, and quota limits
- Language setting for speech (en-US, ur-PK, hi-IN, fa-IR, ps-AF; depends on languages installed on the phone)

## Not built yet
Wake word, holographic face, phone automation, Windows agent, remote link, memory screen, PIN/biometrics.

## Build
1. Install Android Studio (latest). Open the `Android` folder. Let it sync (it creates the Gradle wrapper).
2. Get a free key at https://aistudio.google.com/apikey
3. Plug in the TECNO phone (USB debugging on) and press Run.
4. In the app: Settings → paste the API key → Save.

## Release APK
Build → Generate Signed Bundle / APK → APK → create a keystore (keep it and its password safe) → release.
Notes: the model name is editable in Settings in case Google renames models.
