import ctypes, datetime, os, pathlib, re, socket, struct, subprocess, webbrowser
from urllib.parse import urlparse
from config import APP_DIR, NOTES_DIR

SCRIPTS_DIR = APP_DIR / "scripts"   # only scripts YOU put here can be run remotely

class _Power(ctypes.Structure):
    _fields_ = [("ac", ctypes.c_ubyte), ("flag", ctypes.c_ubyte), ("pct", ctypes.c_ubyte), ("sys", ctypes.c_ubyte),
                ("life", ctypes.c_ulong), ("full", ctypes.c_ulong)]

class _POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

class _MI(ctypes.Structure):
    _fields_ = [("dx", ctypes.c_long), ("dy", ctypes.c_long), ("mouseData", ctypes.c_ulong), ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong), ("dwExtraInfo", ctypes.c_size_t)]
class _KI(ctypes.Structure):
    _fields_ = [("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort), ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong), ("dwExtraInfo", ctypes.c_size_t)]
class _HI(ctypes.Structure):
    _fields_ = [("uMsg", ctypes.c_ulong), ("wParamL", ctypes.c_ushort), ("wParamH", ctypes.c_ushort)]
class _U(ctypes.Union):
    _fields_ = [("mi", _MI), ("ki", _KI), ("hi", _HI)]
class _INPUT(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong), ("u", _U)]

VK = {"ctrl": 0x11, "control": 0x11, "alt": 0x12, "shift": 0x10, "win": 0x5B, "windows": 0x5B, "enter": 0x0D,
      "esc": 0x1B, "escape": 0x1B, "tab": 0x09, "space": 0x20, "backspace": 0x08, "delete": 0x2E,
      "up": 0x26, "down": 0x28, "left": 0x25, "right": 0x27, "home": 0x24, "end": 0x23, "pageup": 0x21, "pagedown": 0x22}
for _i in range(1, 13):
    VK[f"f{_i}"] = 0x6F + _i

APPS = {"chrome": "chrome", "google chrome": "chrome", "edge": "msedge", "firefox": "firefox", "word": "winword",
        "excel": "excel", "powerpoint": "powerpnt", "paint": "mspaint", "settings": "ms-settings:", "task manager": "taskmgr",
        "spotify": "spotify", "vlc": "vlc", "whatsapp": "whatsapp:"}
BLOCKED_APPS = {"cmd", "powershell", "pwsh", "regedit", "mshta", "wscript", "cscript", "bash", "wsl", "reg", "diskpart"}

def _status() -> str:
    parts = [f"{socket.gethostname()} is online"]
    if os.name == "nt":
        p = _Power()
        if ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(p)) and p.pct != 255:
            parts.append(f"battery {p.pct}%{' (plugged in)' if p.ac == 1 else ''}")
        ms = ctypes.windll.kernel32.GetTickCount64()
        parts.append(f"up {ms // 3_600_000}h {(ms // 60_000) % 60}m")
    try:
        socket.create_connection(("1.1.1.1", 53), 2).close(); parts.append("internet OK")
    except OSError:
        parts.append("no internet")
    return ", ".join(parts) + "."

def _key(vk: int, up: bool) -> None:
    ctypes.windll.user32.keybd_event(vk, 0, 2 if up else 0, 0)

def _type_text(text: str) -> None:
    u = ctypes.windll.user32
    for ch in text[:500]:
        if ch == "\n":
            _key(VK["enter"], False); _key(VK["enter"], True); continue
        data = ch.encode("utf-16-le")
        for unit in struct.unpack("<%dH" % (len(data) // 2), data):
            for flags in (0x0004, 0x0004 | 0x0002):
                inp = _INPUT(1, _U(ki=_KI(0, unit, flags, 0, 0)))
                u.SendInput(1, ctypes.byref(inp), ctypes.sizeof(_INPUT))

def _hotkey(keys: list) -> str:
    codes = []
    for k in keys[:5]:
        k = str(k).lower()
        if k in VK: codes.append(VK[k])
        elif len(k) == 1 and k.isalnum(): codes.append(ord(k.upper()))
        else: return f"I don't know the key \"{k}\"."
    if not codes: return "No keys given."
    for c in codes: _key(c, False)
    for c in reversed(codes): _key(c, True)
    return "Pressed " + "+".join(str(k) for k in keys[:5]) + "."

def _mouse_click(button: str, double: bool) -> str:
    d, up = (0x0008, 0x0010) if button == "right" else (0x0002, 0x0004)
    for _ in range(2 if double else 1):
        ctypes.windll.user32.mouse_event(d, 0, 0, 0, 0); ctypes.windll.user32.mouse_event(up, 0, 0, 0, 0)
    return ("Double-clicked." if double else "Clicked.") if button != "right" else "Right-clicked."

def _mouse_move(direction: str, amount: int) -> str:
    amount = max(1, min(int(amount), 1500))
    p = _POINT(); ctypes.windll.user32.GetCursorPos(ctypes.byref(p))
    dx, dy = {"left": (-amount, 0), "right": (amount, 0), "up": (0, -amount), "down": (0, amount)}.get(direction, (0, 0))
    ctypes.windll.user32.SetCursorPos(p.x + dx, p.y + dy)
    return f"Moved the mouse {direction}."

def _search(query: str) -> str:
    q = query.lower().strip()
    if len(q) < 2: return "Tell me a longer file name to search for."
    hits, seen = [], 0
    for folder in ("Documents", "Desktop", "Downloads"):   # authorised folders only
        for dp, _dn, fn in os.walk(pathlib.Path.home() / folder):
            for f in fn:
                seen += 1
                if q in f.lower(): hits.append(f"{f} (in {pathlib.Path(dp).name})")
                if len(hits) >= 5 or seen > 30000: break
            if len(hits) >= 5 or seen > 30000: break
    return ("Found: " + "; ".join(hits) + ".") if hits else "I didn't find any matching files in Documents, Desktop or Downloads."

def _launch(name: str) -> str:
    name = name.strip().lower()
    if not re.fullmatch(r"[a-z0-9 ._-]{1,60}", name): return "That app name isn't allowed."
    exe = APPS.get(name, name)
    if exe.split(".")[0] in BLOCKED_APPS: return "I'm not allowed to open that."
    os.startfile(exe)
    return f"Opened {name} on the laptop."

def _script(name: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9_ -]{1,40}", name): return "That script name isn't allowed."
    SCRIPTS_DIR.mkdir(parents=True, exist_ok=True)
    for ext in (".bat", ".cmd", ".ps1"):
        f = SCRIPTS_DIR / (name.replace(" ", "_") + ext)
        if f.exists():
            cmd = ["cmd", "/c", str(f)] if ext != ".ps1" else ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(f)]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=60, cwd=str(SCRIPTS_DIR), creationflags=0x08000000)
            out = (r.stdout or r.stderr or "").strip()[-300:]
            return f"Script finished (code {r.returncode}). {out}"
    return f"No script named {name}. Put .bat or .ps1 files in {SCRIPTS_DIR}."

def _power(mode: str) -> str:
    if mode == "shutdown": subprocess.run(["shutdown", "/s", "/t", "30"]); return "Shutting down in 30 seconds. Say 'cancel shutdown' to stop it."
    if mode == "restart": subprocess.run(["shutdown", "/r", "/t", "30"]); return "Restarting in 30 seconds. Say 'cancel shutdown' to stop it."
    if mode == "cancel": subprocess.run(["shutdown", "/a"]); return "Cancelled."
    if mode == "sleep": subprocess.Popen(["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"]); return "Going to sleep."
    return "Unknown power mode."

def run(action: str, args: dict, allowed: list) -> tuple:
    """Only these fixed actions exist. There is no free-form shell access."""
    if action not in allowed:
        return False, "That action is turned off on the laptop."
    try:
        if action == "status":
            return True, _status()
        if os.name != "nt":
            return False, "This action only works on Windows."
        if action == "lock":
            ctypes.windll.user32.LockWorkStation(); return True, "Laptop locked."
        if action == "open_notepad":
            subprocess.Popen(["notepad.exe"]); return True, "Notepad is open on the laptop."
        if action == "open_calculator":
            subprocess.Popen(["calc.exe"]); return True, "Calculator is open on the laptop."
        if action == "open_explorer":
            NOTES_DIR.mkdir(parents=True, exist_ok=True); subprocess.Popen(["explorer.exe", str(NOTES_DIR)]); return True, "File Explorer is open."
        if action == "open_url":
            u = urlparse(str(args.get("url", "")))
            if u.scheme not in ("http", "https") or not u.netloc:
                return False, "Only http/https links are allowed."
            webbrowser.open(u.geturl()); return True, "Opened the link on the laptop."
        if action == "create_note":
            text = str(args.get("text", "")).strip()[:5000]
            if not text:
                return False, "The note was empty."
            NOTES_DIR.mkdir(parents=True, exist_ok=True)
            f = NOTES_DIR / f"note_{datetime.datetime.now():%Y%m%d_%H%M%S}.txt"
            f.write_text(text, "utf-8"); return True, f"Note saved as {f.name} in Documents/TUS_Notes."
        if action == "launch_app":
            m = _launch(str(args.get("name", ""))); return m.startswith("Opened"), m
        if action == "type_text":
            _type_text(str(args.get("text", ""))); return True, "Typed it on the laptop."
        if action == "hotkey":
            m = _hotkey(list(args.get("keys", []))); return m.startswith("Pressed"), m
        if action == "mouse_click":
            return True, _mouse_click(str(args.get("button", "left")), bool(args.get("double", False)))
        if action == "mouse_move":
            return True, _mouse_move(str(args.get("direction", "")), int(args.get("amount", 150)))
        if action == "volume":
            vk = {"up": 0xAF, "down": 0xAE, "mute": 0xAD}.get(str(args.get("dir", "")))
            if not vk: return False, "Unknown volume command."
            for _ in range(1 if vk == 0xAD else max(1, min(int(args.get("steps", 5)), 25))): _key(vk, False); _key(vk, True)
            return True, "Volume changed."
        if action == "media":
            vk = {"play_pause": 0xB3, "next": 0xB0, "previous": 0xB1}.get(str(args.get("key", "")))
            if not vk: return False, "Unknown media key."
            _key(vk, False); _key(vk, True); return True, "Done."
        if action == "search_files":
            m = _search(str(args.get("query", ""))); return True, m
        if action == "run_script":
            m = _script(str(args.get("name", ""))); return m.startswith("Script finished"), m
        if action == "power":
            return True, _power(str(args.get("mode", "")))
        return False, "Unknown action."
    except Exception as e:
        return False, f"Action failed: {e}"
