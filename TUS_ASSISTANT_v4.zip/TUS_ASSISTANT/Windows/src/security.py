import datetime, hashlib, hmac, json, secrets, threading, time
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID
from config import APP_DIR

CERT, KEY = APP_DIR / "agent_cert.pem", APP_DIR / "agent_key.pem"
DEVICES, AUDIT = APP_DIR / "devices.json", APP_DIR / "audit.log"
_lock = threading.Lock()

def ensure_cert() -> str:
    """Creates a self-signed certificate on first run. Returns its SHA-256 fingerprint (hex)."""
    if not (CERT.exists() and KEY.exists()):
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "TUS Agent")])
        now = datetime.datetime.now(datetime.timezone.utc)
        cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
                .serial_number(x509.random_serial_number()).not_valid_before(now - datetime.timedelta(days=1))
                .not_valid_after(now + datetime.timedelta(days=3650)).sign(key, hashes.SHA256()))
        KEY.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
        CERT.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    cert = x509.load_pem_x509_certificate(CERT.read_bytes())
    return hashlib.sha256(cert.public_bytes(serialization.Encoding.DER)).hexdigest()

def audit(event: str, **kw) -> None:
    line = json.dumps({"time": datetime.datetime.now().isoformat(timespec="seconds"), "event": event, **kw})
    with _lock, open(AUDIT, "a", encoding="utf-8") as f:
        f.write(line + "\n")

def _h(secret: str) -> str:
    return hashlib.sha256(secret.encode()).hexdigest()

class Devices:
    def _read(self) -> dict:
        try:
            return json.loads(DEVICES.read_text("utf-8"))
        except Exception:
            return {}
    def _write(self, d: dict) -> None:
        DEVICES.write_text(json.dumps(d, indent=2), "utf-8")
    def add(self, device_id: str, name: str) -> str:
        secret = secrets.token_urlsafe(32)
        with _lock:
            d = self._read()
            d[device_id] = {"name": name[:60], "hash": _h(secret), "created": time.time(), "last_seen": 0}
            self._write(d)
        return secret
    def verify(self, device_id: str, secret: str) -> bool:
        with _lock:
            d = self._read()
            rec = d.get(device_id)
            ok = bool(rec) and hmac.compare_digest(rec["hash"], _h(secret or ""))
            if ok:
                rec["last_seen"] = time.time(); self._write(d)
            return ok
    def revoke(self, device_id: str) -> None:
        with _lock:
            d = self._read(); d.pop(device_id, None); self._write(d)
    def list(self) -> dict:
        with _lock:
            return self._read()

class Pairing:
    """One-time 6-digit code, valid 5 minutes, locked out after 5 wrong tries."""
    def __init__(self):
        self.code, self.expires, self.fails, self.locked_until = None, 0.0, 0, 0.0
    def start(self) -> str:
        self.code = f"{secrets.randbelow(1_000_000):06d}"; self.expires = time.time() + 300; self.fails = 0
        return self.code
    def redeem(self, attempt: str) -> bool:
        now = time.time()
        if now < self.locked_until or not self.code or now > self.expires:
            return False
        if hmac.compare_digest(self.code, str(attempt)):
            self.code = None; return True
        self.fails += 1
        if self.fails >= 5:
            self.locked_until = now + 300; self.code = None
        return False
