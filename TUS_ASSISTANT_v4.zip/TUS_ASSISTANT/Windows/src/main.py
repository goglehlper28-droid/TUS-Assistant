import sys, tkinter.messagebox as mb
import server, ui

def main():
    holder = {}
    agent = server.Agent(lambda m: holder["app"].event(m) if "app" in holder else None)
    app = ui.App(agent); holder["app"] = app
    try:
        agent.start()
    except OSError as e:
        mb.showerror("TUS", f"Couldn't start the agent on {agent.bind_ip}:{agent.cfg['port']}: {e}")
    app.run(); agent.stop()

if __name__ == "__main__":
    main()
