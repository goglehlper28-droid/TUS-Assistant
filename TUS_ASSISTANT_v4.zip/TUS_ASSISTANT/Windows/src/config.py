import json, os, pathlib

APP_DIR = pathlib.Path(os.environ.get("APPDATA", str(pathlib.Path.home()))) / "TUS"
APP_DIR.mkdir(parents=True, exist_ok=True)
NOTES_DIR = pathlib.Path.home() / "Documents" / "TUS_Notes"
CONFIG_FILE = APP_DIR / "config.json"

DEFAULTS = {
    "port": 8443,
    "bind": "auto",  # "auto" = Tailscale IP if found, else LAN (0.0.0.0). Or set an exact IP.
    "model": "gemini-flash-latest",
    "tts_model": "gemini-3.1-flash-tts-preview",
    "tts_voice": "Charon",
    "speak": True,
    # Remote actions the phone may trigger. Remove one to disable it.
    "allowed_actions": ["status", "lock", "open_notepad", "open_calculator", "open_explorer", "open_url", "create_note",
                        "launch_app", "type_text", "hotkey", "mouse_click", "mouse_move", "volume", "media",
                        "search_files", "run_script", "power"],
}

def load() -> dict:
    cfg = dict(DEFAULTS)
    try:
        cfg.update(json.loads(CONFIG_FILE.read_text("utf-8")))
    except Exception:
        pass
    return cfg

def save(cfg: dict) -> None:
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2), "utf-8")
