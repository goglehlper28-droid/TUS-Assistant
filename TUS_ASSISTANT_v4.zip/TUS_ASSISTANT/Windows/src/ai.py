import json, urllib.request, urllib.error
import keyring

PROMPT = ("You are TUS, The Universal Smart Assistant, personal AI assistant of your owner Farid Ghani. Be friendly, smart, "
          "a little playful, concise. Be loyal and respectful to Farid; if someone insults him, stay calm and defend his dignity politely. "
          "Reply in the user's language (English, Urdu, Roman Urdu, Pashto, Farsi, Hindi, or mixed). Never claim you did something you cannot do.")

def get_key() -> str: return keyring.get_password("TUS", "gemini") or ""
def set_key(k: str) -> None: keyring.set_password("TUS", "gemini", k.strip())

def ask(history: list, model: str) -> str:
    key = get_key()
    if not key: return "No API key yet. Click Settings and paste your Gemini API key."
    body = {"systemInstruction": {"parts": [{"text": PROMPT}]},
            "contents": [{"role": r, "parts": [{"text": t}]} for r, t in history]}
    req = urllib.request.Request(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                                 json.dumps(body).encode(), {"Content-Type": "application/json", "x-goog-api-key": key})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            data = json.load(r)
        return "".join(p.get("text", "") for p in data["candidates"][0]["content"]["parts"]) or "No answer came back."
    except urllib.error.HTTPError as e:
        if e.code == 429: return "Quota or rate limit reached. Wait a minute or check your Gemini plan."
        if e.code in (400, 401, 403): return "Gemini rejected the request. Check your API key and model name."
        return f"Gemini error {e.code}."
    except Exception as e:
        return f"Couldn't reach Gemini: {e}"


def speak_wav(text: str, model: str, voice: str):
    """Natural Gemini voice as WAV bytes, or None if anything fails."""
    import base64, io, wave
    key = get_key()
    if not key: return None
    body = {"contents": [{"parts": [{"text": "Say in a warm, natural, friendly human tone: " + text[:900]}]}],
            "generationConfig": {"responseModalities": ["AUDIO"],
                                 "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voice}}}}}
    req = urllib.request.Request(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                                 json.dumps(body).encode(), {"Content-Type": "application/json", "x-goog-api-key": key})
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            data = json.load(r)
        for p in data["candidates"][0]["content"]["parts"]:
            if "inlineData" in p:
                pcm = base64.b64decode(p["inlineData"]["data"])
                buf = io.BytesIO()
                with wave.open(buf, "wb") as w:
                    w.setnchannels(1); w.setsampwidth(2); w.setframerate(24000); w.writeframes(pcm)
                return buf.getvalue()
    except Exception:
        return None
    return None
