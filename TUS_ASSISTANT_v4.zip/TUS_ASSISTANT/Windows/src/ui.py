import math, os, sys, threading, time, tkinter as tk
from tkinter import messagebox, simpledialog
import ai, config, voice_in

BG, BLUE, CYAN = "#05070D", "#29B6FF", "#7DF3FF"

def set_startup(enable: bool) -> None:
    import winreg
    k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_SET_VALUE)
    if enable: winreg.SetValueEx(k, "TUS_Agent", 0, winreg.REG_SZ, f'"{sys.executable}"')
    else:
        try: winreg.DeleteValue(k, "TUS_Agent")
        except FileNotFoundError: pass

class App:
    def __init__(self, agent):
        self.agent, self.cfg, self.history, self.speaking = agent, config.load(), [], False
        r = self.root = tk.Tk(); r.title("TUS — The Universal Smart Assistant"); r.configure(bg=BG); r.geometry("760x720")
        self.face = tk.Canvas(r, width=740, height=210, bg=BG, highlightthickness=0); self.face.pack(pady=4)
        self.status = tk.Label(r, text="", fg=CYAN, bg=BG, justify="left", font=("Segoe UI", 9)); self.status.pack(anchor="w", padx=10)
        bar = tk.Frame(r, bg=BG); bar.pack(fill="x", padx=10, pady=4)
        for txt, cmd in [("Pair new phone", self.pair), ("Revoke selected device", self.revoke), ("Settings", self.settings)]:
            tk.Button(bar, text=txt, command=cmd, bg="#0B3A5B", fg="white", relief="flat").pack(side="left", padx=3)
        self.devs = tk.Listbox(r, height=3, bg="#111A28", fg="white"); self.devs.pack(fill="x", padx=10)
        self.log = tk.Text(r, height=7, bg="#0B0F18", fg="#9fd8ff", state="disabled"); self.log.pack(fill="x", padx=10, pady=4)
        self.chat = tk.Text(r, bg="#111A28", fg="white", wrap="word", state="disabled"); self.chat.pack(fill="both", expand=True, padx=10)
        row = tk.Frame(r, bg=BG); row.pack(fill="x", padx=10, pady=6)
        self.entry = tk.Entry(row, bg="#111A28", fg="white", insertbackground="white"); self.entry.pack(side="left", fill="x", expand=True)
        self.entry.bind("<Return>", lambda e: self.send())
        tk.Button(row, text="Send", command=self.send, bg=BLUE, relief="flat").pack(side="left", padx=4)
        tk.Button(row, text="Speak", command=self.listen, bg="#0B3A5B", fg="white", relief="flat").pack(side="left", padx=4)
        self.t0 = time.time(); self.animate(); self.refresh()

    def event(self, msg: str):
        self.root.after(0, lambda: self._append(self.log, f"{time.strftime('%H:%M:%S')}  {msg}\n"))
    def _append(self, w, text):
        w.config(state="normal"); w.insert("end", text); w.see("end"); w.config(state="disabled")

    def refresh(self):
        a = self.agent
        self.status.config(text=f"Agent: {a.bind_ip}:{a.cfg['port']} ({a.bind_kind})\nCertificate fingerprint (compare with phone): {a.fingerprint[:32]}…")
        self.devs.delete(0, "end")
        self.ids = list(a.devices.list().keys())
        for i in self.ids: self.devs.insert("end", f"{a.devices.list()[i]['name']}  [{i[:8]}]")
        self.root.after(5000, self.refresh)

    def pair(self):
        code = self.agent.pairing.start()
        messagebox.showinfo("Pair new phone", f"On the phone: Settings → Laptop link.\nAddress: {self.agent.bind_ip}\nPort: {self.agent.cfg['port']}\nCode: {code}\n\nValid for 5 minutes.\nFingerprint: {self.agent.fingerprint[:32]}…")
    def revoke(self):
        s = self.devs.curselection()
        if s and messagebox.askyesno("Revoke", "Remove this phone's access?"):
            self.agent.devices.revoke(self.ids[s[0]]); self.event("Device revoked")
    def settings(self):
        k = simpledialog.askstring("Gemini API key", "Paste your Gemini API key (saved in Windows Credential Manager):", show="*")
        if k: ai.set_key(k)
        if messagebox.askyesno("Startup", "Start TUS automatically when Windows starts?"):
            try: set_startup(True)
            except Exception as e: messagebox.showerror("Startup", str(e))
        else:
            try: set_startup(False)
            except Exception: pass

    def send(self):
        t = self.entry.get().strip()
        if not t: return
        self.entry.delete(0, "end"); self._append(self.chat, f"You: {t}\n"); self.history.append(("user", t))
        def work():
            r = ai.ask(self.history, self.cfg["model"])
            if not r.startswith(("No API", "Quota", "Gemini", "Couldn't")): self.history.append(("model", r))
            self.root.after(0, lambda: self._append(self.chat, f"TUS: {r}\n\n"))
            if self.cfg["speak"]: self.speak(r)
        threading.Thread(target=work, daemon=True).start()

    def listen(self):
        self.event("Listening… speak now (microphone is on)")
        def work():
            try:
                wav = voice_in.record()
                if not wav:
                    self.event("I didn't hear anything. Microphone is off."); return
                self.event("Microphone is off. Understanding…")
                text = voice_in.transcribe(wav, self.cfg["model"])
                if text:
                    self.root.after(0, lambda: (self.entry.delete(0, "end"), self.entry.insert(0, text), self.send()))
                else:
                    self.event("I couldn't understand that, or no API key is set.")
            except Exception as e:
                self.event(f"Microphone problem: {e}")
        threading.Thread(target=work, daemon=True).start()

    def speak(self, text):
        def run():
            self.speaking = True
            try:
                wav = ai.speak_wav(text, self.cfg["tts_model"], self.cfg["tts_voice"])
                if wav:
                    import tempfile, winsound
                    f = os.path.join(tempfile.gettempdir(), "tus_voice.wav")
                    with open(f, "wb") as fh: fh.write(wav)
                    winsound.PlaySound(f, winsound.SND_FILENAME)
                else:
                    import pyttsx3
                    e = pyttsx3.init(); e.say(text[:800]); e.runAndWait()
            except Exception: pass
            finally: self.speaking = False
        threading.Thread(target=run, daemon=True).start()

    def animate(self):
        c, t = self.face, time.time() - self.t0
        c.delete("all"); cx, cy = 370, 105
        for i, r in enumerate((95, 82, 68)):
            for k in range(4): c.create_arc(cx-r, cy-r, cx+r, cy+r, start=(t*40*(1+i*.4)+k*90) % 360, extent=40, style="arc", outline=BLUE, width=2)
        c.create_oval(cx-45, cy-62, cx+45, cy+62, outline=CYAN, width=2)
        ph = t % 4.2; o = abs(ph-.08)/.08 if ph < .16 else 1
        for s in (-1, 1):
            h = 3 + 8*o; c.create_oval(cx+s*22-14, cy-18-h/2, cx+s*22+14, cy-18+h/2, fill="white", outline=CYAN)
        m = 3 + (abs(math.sin(t*9)*math.sin(t*5.3))*12 if self.speaking else 0)
        c.create_oval(cx-14, cy+34-m/2, cx+14, cy+34+m/2, outline=CYAN, width=2)
        self.root.after(60, self.animate)

    def run(self): self.root.mainloop()
