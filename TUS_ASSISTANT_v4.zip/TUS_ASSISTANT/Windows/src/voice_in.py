import array, base64, io, json, time, urllib.request, wave
import ai

RATE = 16000

def record(max_s: float = 10.0, silence_s: float = 1.2, thresh: int = 900):
    """Records from the default microphone until you stop talking. Returns WAV bytes or None. Only runs when you press Speak."""
    import sounddevice as sd
    chunk, frames, started, quiet = 1600, [], False, 0.0
    t0 = time.time()
    with sd.RawInputStream(samplerate=RATE, channels=1, dtype="int16", blocksize=chunk) as st:
        while time.time() - t0 < max_s:
            data, _ = st.read(chunk)
            buf = bytes(data)
            frames.append(buf)
            peak = max(abs(x) for x in array.array("h", buf))
            if peak > thresh:
                started, quiet = True, 0.0
            elif started:
                quiet += chunk / RATE
                if quiet >= silence_s:
                    break
            elif time.time() - t0 > 4:
                return None
    if not started:
        return None
    out = io.BytesIO()
    with wave.open(out, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(RATE); w.writeframes(b"".join(frames))
    return out.getvalue()

def transcribe(wav: bytes, model: str) -> str:
    key = ai.get_key()
    if not key:
        return ""
    body = {"contents": [{"parts": [
        {"text": "Transcribe this speech exactly in its original language (English, Urdu, Roman Urdu, Pashto, Farsi or Hindi). Output only the transcript."},
        {"inlineData": {"mimeType": "audio/wav", "data": base64.b64encode(wav).decode()}}]}]}
    req = urllib.request.Request(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                                 json.dumps(body).encode(), {"Content-Type": "application/json", "x-goog-api-key": key})
    with urllib.request.urlopen(req, timeout=60) as r:
        data = json.load(r)
    return "".join(p.get("text", "") for p in data["candidates"][0]["content"]["parts"]).strip()
