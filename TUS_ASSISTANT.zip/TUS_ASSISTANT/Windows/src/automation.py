import ctypes, datetime, os, socket, subprocess, webbrowser
from urllib.parse import urlparse
from config import NOTES_DIR

class _Power(ctypes.Structure):
    _fields_ = [("ac", ctypes.c_ubyte), ("flag", ctypes.c_ubyte), ("pct", ctypes.c_ubyte), ("sys", ctypes.c_ubyte),
                ("life", ctypes.c_ulong), ("full", ctypes.c_ulong)]

def _status() -> str:
    parts = [f"{socket.gethostname()} is online"]
    if os.name == "nt":
        p = _Power()
        if ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(p)) and p.pct != 255:
            parts.append(f"battery {p.pct}%{' (plugged in)' if p.ac == 1 else ''}")
        ms = ctypes.windll.kernel32.GetTickCount64()
        parts.append(f"up {ms // 3_600_000}h {(ms // 60_000) % 60}m")
    try:
        socket.create_connection(("1.1.1.1", 53), 2).close(); parts.append("internet OK")
    except OSError:
        parts.append("no internet")
    return ", ".join(parts) + "."

def run(action: str, args: dict, allowed: list) -> tuple:
    """Only these fixed actions exist. There is no shell access."""
    if action not in allowed:
        return False, "That action is turned off on the laptop."
    try:
        if action == "status":
            return True, _status()
        if os.name != "nt":
            return False, "This action only works on Windows."
        if action == "lock":
            ctypes.windll.user32.LockWorkStation(); return True, "Laptop locked."
        if action == "open_notepad":
            subprocess.Popen(["notepad.exe"]); return True, "Notepad is open on the laptop."
        if action == "open_calculator":
            subprocess.Popen(["calc.exe"]); return True, "Calculator is open on the laptop."
        if action == "open_explorer":
            NOTES_DIR.mkdir(parents=True, exist_ok=True); subprocess.Popen(["explorer.exe", str(NOTES_DIR)]); return True, "File Explorer is open."
        if action == "open_url":
            u = urlparse(str(args.get("url", "")))
            if u.scheme not in ("http", "https") or not u.netloc:
                return False, "Only http/https links are allowed."
            webbrowser.open(u.geturl()); return True, "Opened the link on the laptop."
        if action == "create_note":
            text = str(args.get("text", "")).strip()[:5000]
            if not text:
                return False, "The note was empty."
            NOTES_DIR.mkdir(parents=True, exist_ok=True)
            f = NOTES_DIR / f"note_{datetime.datetime.now():%Y%m%d_%H%M%S}.txt"
            f.write_text(text, "utf-8"); return True, f"Note saved as {f.name} in Documents/TUS_Notes."
        return False, "Unknown action."
    except Exception as e:
        return False, f"Action failed: {e}"
