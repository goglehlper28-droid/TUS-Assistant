import json, socket, ssl, subprocess, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import automation, config, security

def resolve_bind(cfg: dict) -> tuple:
    if cfg["bind"] != "auto":
        return cfg["bind"], "custom address"
    try:
        out = subprocess.run(["tailscale", "ip", "-4"], capture_output=True, text=True, timeout=4).stdout.split()
        if out:
            return out[0], "Tailscale"
    except Exception:
        pass
    return "0.0.0.0", "LAN (Tailscale not found; do NOT port-forward this)"

class Agent:
    def __init__(self, on_event):
        self.cfg = config.load()
        self.devices, self.pairing = security.Devices(), security.Pairing()
        self.fingerprint = security.ensure_cert()
        self.on_event, self.httpd = on_event, None
        self.bind_ip, self.bind_kind = resolve_bind(self.cfg)

    def start(self):
        agent = self
        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def _reply(self, code, msg, ok=False):
                data = json.dumps({"ok": ok, "message": msg}).encode()
                self.send_response(code); self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
            def _body(self):
                n = int(self.headers.get("Content-Length", 0))
                if n > 65536: raise ValueError("too large")
                return json.loads(self.rfile.read(n) or b"{}")
            def do_POST(self):
                try:
                    body = self._body()
                    if self.path == "/pair":
                        if agent.pairing.redeem(body.get("code", "")):
                            secret = agent.devices.add(str(body["device_id"])[:64], str(body.get("name", "Phone")))
                            security.audit("paired", device=body.get("name"), ip=self.client_address[0])
                            agent.on_event(f"Paired with {body.get('name')}")
                            data = json.dumps({"ok": True, "secret": secret}).encode()
                            self.send_response(200); self.send_header("Content-Type", "application/json")
                            self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
                        else:
                            security.audit("pair_failed", ip=self.client_address[0])
                            self._reply(403, "Wrong, expired or locked pairing code.")
                    elif self.path == "/command":
                        did, sec = self.headers.get("X-Device-Id", ""), self.headers.get("X-Device-Secret", "")
                        if not agent.devices.verify(did, sec):
                            security.audit("auth_failed", ip=self.client_address[0]); self._reply(401, "This device isn't authorised. Pair again."); return
                        action = str(body.get("action", ""))
                        ok, msg = automation.run(action, body.get("args", {}) or {}, config.load()["allowed_actions"])
                        security.audit("command", action=action, ok=ok, device=did[:8])
                        agent.on_event(f"{action}: {msg}")
                        self._reply(200 if ok else 400, msg, ok)
                    else:
                        self._reply(404, "Not found.")
                except Exception as e:
                    self._reply(400, f"Bad request: {e}")
            def do_GET(self): self._reply(404, "Not found.")

        self.httpd = ThreadingHTTPServer((self.bind_ip, self.cfg["port"]), H)
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(str(security.CERT), str(security.KEY))
        self.httpd.socket = ctx.wrap_socket(self.httpd.socket, server_side=True)
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        security.audit("agent_started", bind=self.bind_ip, port=self.cfg["port"])
        self.on_event(f"Agent online on {self.bind_ip}:{self.cfg['port']} via {self.bind_kind}")

    def stop(self):
        if self.httpd: self.httpd.shutdown()
