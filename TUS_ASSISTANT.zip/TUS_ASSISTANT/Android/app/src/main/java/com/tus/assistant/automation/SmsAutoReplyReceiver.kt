package com.tus.assistant.automation

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telephony.SmsManager
import com.tus.assistant.core.AssistantCore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Optional, off by default (Settings → Auto-reply to texts). When on, replies to incoming SMS using Gemini.
 * Every reply is tagged so the sender always knows they're talking to Farid's AI assistant, never Farid himself.
 */
class SmsAutoReplyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val core = AssistantCore(context.applicationContext)
        if (!core.store.autoReplySms || core.store.apiKey.isBlank()) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        val from = messages.firstOrNull()?.originatingAddress ?: return
        val body = messages.joinToString("") { it.messageBody.orEmpty() }
        if (body.isBlank()) return

        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val reply = core.autoReply(body, from)
                if (reply.isNotBlank()) {
                    val tagged = "[F.G, Farid's AI assistant] $reply"
                    val sm = SmsManager.getDefault()
                    sm.sendMultipartTextMessage(from, null, sm.divideMessage(tagged.take(600)), null, null)
                }
            } catch (e: Exception) {
                // stay silent on failure; never send a broken or misleading message
            } finally {
                pending.finish()
            }
        }
    }
}
