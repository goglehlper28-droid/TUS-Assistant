package com.tus.assistant.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Turn(val role: String, val text: String) // role: "user" or "model"

class GeminiException(message: String) : Exception(message)

/** Streams Gemini replies over SSE. Put behind an interface later to add more providers. */
class GeminiClient(private val apiKey: String, private val model: String) {

    fun stream(history: List<Turn>, systemPrompt: String, webSearch: Boolean = true): Flow<String> = flow {
        if (apiKey.isBlank()) throw GeminiException("No API key set. Open Settings and paste your Gemini API key.")
        val contents = JSONArray()
        history.forEach { t ->
            contents.put(JSONObject().put("role", t.role)
                .put("parts", JSONArray().put(JSONObject().put("text", t.text))))
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("contents", contents)
        if (webSearch) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", apiKey)
            connectTimeout = 15_000; readTimeout = 60_000; doOutput = true
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            if (code != 200) {
                val err = conn.errorStream?.bufferedReader()?.readText().orEmpty()
                throw GeminiException(when (code) {
                    429 -> "Quota or rate limit reached. Wait a minute or check your Gemini plan."
                    400 -> "Request rejected (check model name and API key). ${apiMessage(err)}"
                    401, 403 -> "API key not accepted. ${apiMessage(err)}"
                    in 500..599 -> "Gemini is having trouble right now. Try again shortly."
                    else -> "Error $code. ${apiMessage(err)}"
                })
            }
            conn.inputStream.bufferedReader().useLines { lines ->
                for (line in lines) {
                    if (!line.startsWith("data:")) continue
                    val json = JSONObject(line.removePrefix("data:").trim())
                    val parts = json.optJSONArray("candidates")?.optJSONObject(0)
                        ?.optJSONObject("content")?.optJSONArray("parts") ?: continue
                    for (i in 0 until parts.length()) {
                        val text = parts.optJSONObject(i)?.optString("text").orEmpty()
                        if (text.isNotEmpty()) emit(text)
                    }
                }
            }
        } finally { conn.disconnect() }
    }.flowOn(Dispatchers.IO)

    private fun apiMessage(raw: String) =
        try { JSONObject(raw).getJSONObject("error").getString("message") } catch (e: Exception) { "" }
}
