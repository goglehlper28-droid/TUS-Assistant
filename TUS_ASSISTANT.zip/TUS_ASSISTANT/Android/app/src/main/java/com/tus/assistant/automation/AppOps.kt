package com.tus.assistant.automation

import android.content.Context
import android.content.Intent
import android.net.Uri

/** Android never allows silent install/uninstall for a normal app; both always show the system's own confirmation screen. */
object AppOps {
    fun openInstall(ctx: Context, appName: String): String {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=${Uri.encode(appName)}&c=apps")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { ctx.startActivity(i); "Opened the Play Store search for \"$appName\". Tap Install there; I can't install apps without your tap." }
        catch (e: Exception) {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=${Uri.encode(appName)}&c=apps")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Opened the Play Store page for \"$appName\"."
        }
    }

    fun requestUninstall(ctx: Context, appName: String): String {
        val pm = ctx.packageManager
        val apps = pm.getInstalledApplications(0)
        val match = apps.firstOrNull { pm.getApplicationLabel(it).toString().equals(appName, true) }
            ?: apps.firstOrNull { pm.getApplicationLabel(it).toString().contains(appName, true) }
            ?: return "I couldn't find an app called \"$appName\"."
        val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:${match.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return "Asking Android to uninstall ${pm.getApplicationLabel(match)}. Confirm it on the screen; this step can't be skipped."
    }
}
