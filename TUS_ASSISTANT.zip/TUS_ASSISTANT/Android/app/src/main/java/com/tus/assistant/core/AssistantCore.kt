package com.tus.assistant.core

import android.content.Context
import com.tus.assistant.ai.GeminiClient
import com.tus.assistant.ai.Turn
import com.tus.assistant.automation.Automation
import com.tus.assistant.automation.Outcome
import com.tus.assistant.remote.RemoteClient
import com.tus.assistant.security.SecureStore
import com.tus.assistant.voice.VoiceManager
import kotlinx.coroutines.flow.catch

sealed class Reply {
    data class Text(val text: String) : Reply()
    data class NeedsConfirm(val confirm: Outcome.Confirm) : Reply()
}

/** Shared brain used by both the app screen and the background wake-phrase service. */
class AssistantCore(ctx: Context) {
    val store = SecureStore(ctx)
    val voice = VoiceManager(ctx)
    val remote = RemoteClient(store)
    private val automation = Automation(ctx, store, remote)
    private val history = mutableListOf<Turn>()

    private fun systemPrompt(): String {
        val mem = store.memories()
        return BASE_PROMPT + if (mem.isEmpty()) "" else "\nThings Farid asked you to remember:\n" + mem.joinToString("\n") { "- $it" }
    }

    suspend fun process(text: String, onPartial: (String) -> Unit): Reply {
        try {
            when (val o = automation.handle(text)) {
                is Outcome.Done -> return Reply.Text(o.text)
                is Outcome.Confirm -> return Reply.NeedsConfirm(o)
                Outcome.NotHandled -> {}
            }
        } catch (e: Exception) { return Reply.Text("⚠️ ${e.message ?: "That action failed."}") }

        history += Turn("user", text)
        val sb = StringBuilder()
        var error: String? = null
        GeminiClient(store.apiKey, store.model).stream(history, systemPrompt())
            .catch { e -> error = e.message ?: "Something went wrong." }
            .collect { chunk -> sb.append(chunk); onPartial(sb.toString()) }
        if (sb.isEmpty()) { history.removeAt(history.lastIndex); return Reply.Text("⚠️ ${error ?: "No answer came back."}") }
        history += Turn("model", sb.toString())
        if (history.size > 40) repeat(2) { history.removeAt(0) }
        return Reply.Text(sb.toString() + (error?.let { "\n\n⚠️ $it" } ?: ""))
    }

    fun clear() { history.clear() }
    fun shutdown() = voice.shutdown()

    companion object {
        const val BASE_PROMPT = """You are TUS, The Universal Smart Assistant, the personal AI assistant of your owner, Farid Ghani.
Be friendly, intelligent, a little playful, and natural, like a capable human assistant, not a robot. Keep replies concise, since they may be spoken aloud.
You are loyal and respectful to Farid and you look out for him. If someone insults him, stay calm and dignified and defend his dignity politely; don't escalate.
Reply in the language the user writes in, including Urdu, Roman Urdu, Pashto, Farsi, Hindi, or mixed English. Ask for clarification only when truly needed.
Never claim you did something on a phone or laptop unless a real tool did it; you can't do it from this chat."""
    }
}
