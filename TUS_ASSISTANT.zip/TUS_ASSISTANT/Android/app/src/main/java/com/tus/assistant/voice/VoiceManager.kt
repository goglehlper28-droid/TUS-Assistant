package com.tus.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import kotlin.coroutines.resume

/** Android speech-to-text and text-to-speech. Must be used from the main thread. */
class VoiceManager(private val context: Context) {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var waiter: CompletableDeferred<Unit>? = null

    var onSpeakingChanged: (Boolean) -> Unit = {}

    init {
        tts = TextToSpeech(context) { status -> ttsReady = status == TextToSpeech.SUCCESS }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { onSpeakingChanged(true) }
            override fun onDone(id: String?) { onSpeakingChanged(false); waiter?.complete(Unit) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { onSpeakingChanged(false); waiter?.complete(Unit) }
        })
    }

    fun speak(text: String, languageTag: String, flush: Boolean = false) {
        if (!ttsReady) { waiter?.complete(Unit); return }
        tts?.language = Locale.forLanguageTag(languageTag)
        tts?.speak(text.take(3500), if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "tus-${System.nanoTime()}")
    }

    /** Speaks and suspends until finished (so the mic doesn't hear TUS itself). */
    suspend fun speakAndWait(text: String, languageTag: String) {
        waiter = CompletableDeferred()
        speak(text, languageTag, flush = true)
        withTimeoutOrNull(45_000) { waiter?.await() }
    }

    fun stopSpeaking() { tts?.stop(); onSpeakingChanged(false) }

    fun listen(languageTag: String, onText: (String) -> Unit, onFail: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onFail("Speech recognition isn't available on this device."); return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) onFail("I didn't catch that.") else onText(text)
            }
            override fun onError(error: Int) {
                onFail(when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't hear anything."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is needed."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network problem during recognition."
                    else -> "Speech recognition error ($error)."
                })
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        recognizer = r
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
        })
    }

    suspend fun listenOnce(languageTag: String): String? = suspendCancellableCoroutine { cont ->
        listen(languageTag, onText = { if (cont.isActive) cont.resume(it) }, onFail = { if (cont.isActive) cont.resume(null) })
        cont.invokeOnCancellation { recognizer?.cancel() }
    }

    fun cancelListening() { recognizer?.cancel() }
    fun shutdown() { recognizer?.destroy(); tts?.shutdown() }
}
