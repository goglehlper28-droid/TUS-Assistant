package com.tus.assistant.automation

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent
import com.tus.assistant.remote.RemoteClient
import com.tus.assistant.security.SecureStore
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date

sealed class Outcome {
    data class Done(val text: String) : Outcome()
    data class Confirm(val prompt: String, val needsPin: Boolean, val run: suspend () -> String) : Outcome()
    object NotHandled : Outcome()
}

/** Rule-based commands that use official Android intents. Everything sensitive asks for confirmation first. */
class Automation(private val ctx: Context, private val store: SecureStore, private val remote: RemoteClient) {

    suspend fun handle(raw: String): Outcome {
        val rawT = raw.trim().trimEnd('.', '!', '?')
        var t = rawT.lowercase()
        t = t.replace("kholo", "open").replace("khol do", "open").replace("kholna", "open")
        val laptopWords = listOf("laptop", "computer", " pc", "لیپ", "کمپیوٹر")
        if (laptopWords.any { t.contains(it) } && !t.startsWith("remember")) return laptop(t)

        Regex("^(remember|yaad rakho)( that)? (.+)").find(t)?.let {
            val l = store.memories(); l.add(it.groupValues[3]); store.saveMemories(l)
            return Outcome.Done("Got it, I'll remember that. You can view or delete it in Settings → Memory.")
        }
        Regex("^(take a note|make a note|create a note|note down|note)( that|:)? (.+)").find(t)?.let {
            val l = store.notes(); l.add(rawT.takeLast(it.groupValues[3].length)); store.saveNotes(l)
            return Outcome.Done("Note saved.")
        }
        if (Regex("what('?s| is)? the time|current time|time kya|time batao").containsMatchIn(t))
            return Outcome.Done("It's ${DateFormat.getTimeInstance(DateFormat.SHORT).format(Date())}.")
        if (Regex("(today'?s|the|current) date|what day").containsMatchIn(t))
            return Outcome.Done("Today is ${DateFormat.getDateInstance(DateFormat.FULL).format(Date())}.")
        if (t.contains("battery") && !t.startsWith("open")) return Outcome.Done(battery())
        if (Regex("(internet|wifi|wi-fi|network|connection) status|am i connected|am i online").containsMatchIn(t)) return Outcome.Done(connectivity())

        Regex("^(call|dial|phone) ([+0-9 \\-]{5,})$").find(t)?.let {
            val num = it.groupValues[2].replace(" ", "")
            return Outcome.Confirm("Call $num?", false) { start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num"))); "Opening the dialer for $num." }
        }
        Regex("^(send )?(sms|text|message) (to )?([+0-9\\-]{5,}) (saying |say |that )?(.+)").find(t)?.let {
            val num = it.groupValues[4]
            val body = rawT.takeLast(it.groupValues[6].length)
            return Outcome.Confirm("Prepare a text to $num: \"$body\"?", false) {
                start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).putExtra("sms_body", body)); "Message ready. Press send in your messaging app."
            }
        }
        Regex("^(whatsapp|share on whatsapp|send on whatsapp) (.+)").find(t)?.let {
            val body = rawT.takeLast(it.groupValues[2].length)
            return Outcome.Confirm("Share \"$body\" on WhatsApp?", false) {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, body).setPackage("com.whatsapp")
                if (i.resolveActivity(ctx.packageManager) == null) "WhatsApp isn't installed." else { start(i); "WhatsApp is open, pick a chat." }
            }
        }
        Regex("remind me (?:to )?(.+?) in (\\d+) ?(minute|min|hour|hr)s?").find(t)?.let {
            val secs = it.groupValues[2].toInt() * if (it.groupValues[3].startsWith("h")) 3600 else 60
            start(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs)
                .putExtra(AlarmClock.EXTRA_MESSAGE, it.groupValues[1]).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return Outcome.Done("Reminder timer set for ${it.groupValues[2]} ${it.groupValues[3]}(s): ${it.groupValues[1]}.")
        }
        media(t)?.let { return Outcome.Done(it) }
        Regex("^open (.+)").find(t)?.let { return Outcome.Done(open(it.groupValues[1].trim())) }
        Regex("^(search|google) (for )?(.+)").find(t)?.let {
            start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(it.groupValues[3]))))
            return Outcome.Done("Searching for ${it.groupValues[3]}.")
        }
        Regex("^(play|search) (.+) on youtube").find(t)?.let {
            start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(it.groupValues[2]))))
            return Outcome.Done("Searching YouTube for ${it.groupValues[2]}.")
        }
        return Outcome.NotHandled
    }

    // ---------- laptop ----------
    private suspend fun laptop(t: String): Outcome {
        if (!remote.isPaired()) return Outcome.Done("Your laptop isn't paired yet. Install the TUS Windows agent, then open Settings → Laptop link and pair with the code shown on the laptop.")
        return when {
            t.contains("lock") -> {
                if (!store.hasPin) Outcome.Done("Set a PIN in Settings → Security first. Locking the laptop needs your PIN.")
                else Outcome.Confirm("Lock your laptop? Enter your PIN.", true) { remote.command("lock").message }
            }
            t.contains("notepad") -> Outcome.Done(remote.command("open_notepad").message)
            t.contains("calculator") || t.contains("calc") -> Outcome.Done(remote.command("open_calculator").message)
            t.contains("explorer") || t.contains("files") -> Outcome.Done(remote.command("open_explorer").message)
            Regex("note (.+)").containsMatchIn(t) ->
                Outcome.Done(remote.command("create_note", JSONObject().put("text", Regex("note (.+)").find(t)!!.groupValues[1])).message)
            else -> Outcome.Done(remote.command("status").message)
        }
    }

    // ---------- helpers ----------
    private fun start(i: Intent) { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    private fun open(target: String): String {
        val settings = mapOf(
            "wifi settings" to Settings.ACTION_WIFI_SETTINGS, "wi-fi settings" to Settings.ACTION_WIFI_SETTINGS,
            "bluetooth settings" to Settings.ACTION_BLUETOOTH_SETTINGS, "bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
            "display settings" to Settings.ACTION_DISPLAY_SETTINGS, "sound settings" to Settings.ACTION_SOUND_SETTINGS,
            "battery settings" to Settings.ACTION_BATTERY_SAVER_SETTINGS, "settings" to Settings.ACTION_SETTINGS
        )
        settings[target]?.let { start(Intent(it)); return "Opening $target." }
        if (target.contains(".") && !target.contains(" ")) {
            start(Intent(Intent.ACTION_VIEW, Uri.parse(if (target.startsWith("http")) target else "https://$target"))); return "Opening $target."
        }
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().equals(target, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(target, true) }
        if (match != null) {
            pm.getLaunchIntentForPackage(match.activityInfo.packageName)?.let { start(it); return "Opening ${match.loadLabel(pm)}." }
        }
        if (target == "youtube") { start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))); return "Opening YouTube in the browser." }
        return "I couldn't find an app called \"$target\" on this phone."
    }

    private fun media(t: String): String? {
        val key = when {
            Regex("^(pause|stop) (the )?(music|song|media|video)").containsMatchIn(t) -> KeyEvent.KEYCODE_MEDIA_PAUSE
            Regex("^(play|resume) (the )?(music|song|media)$").containsMatchIn(t) -> KeyEvent.KEYCODE_MEDIA_PLAY
            Regex("^next (song|track)").containsMatchIn(t) -> KeyEvent.KEYCODE_MEDIA_NEXT
            Regex("^(previous|last) (song|track)").containsMatchIn(t) -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return null
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
        return "Done."
    }

    private fun battery(): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return "I can't read the battery right now."
        val pct = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) * 100 / i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        return "Battery is at $pct%${if (charging) " and charging" else ""}."
    }

    private fun connectivity(): String {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "You're offline."
        val kind = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            else -> "a network"
        }
        return "You're online via $kind."
    }
}
