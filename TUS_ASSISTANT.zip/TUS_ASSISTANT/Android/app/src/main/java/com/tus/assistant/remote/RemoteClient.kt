package com.tus.assistant.remote

import android.os.Build
import com.tus.assistant.security.SecureStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

/**
 * Talks to the TUS Windows agent over HTTPS. The agent uses a self-signed certificate, so after
 * pairing we PIN its SHA-256 fingerprint; any other certificate is rejected.
 */
class RemoteClient(private val store: SecureStore) {
    data class Reply(val ok: Boolean, val message: String)

    private class PinTrust(private val expected: String?) : X509TrustManager {
        var seen = ""
        override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
        override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {
            seen = MessageDigest.getInstance("SHA-256").digest(chain[0].encoded).joinToString("") { "%02x".format(it) }
            if (expected != null && !seen.equals(expected, ignoreCase = true))
                throw CertificateException("The laptop's security certificate changed. Pair again only if you trust the change.")
        }
        override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
    }

    fun isPaired() = store.remoteHost.isNotEmpty() && store.remoteSecret.isNotEmpty()

    private fun post(host: String, port: Int, path: String, body: JSONObject, headers: Map<String, String>, pin: String?): Triple<Int, String, String> {
        val tm = PinTrust(pin)
        val ctx = SSLContext.getInstance("TLS").apply { init(null, arrayOf(tm), SecureRandom()) }
        val conn = (URL("https://$host:$port$path").openConnection() as HttpsURLConnection).apply {
            sslSocketFactory = ctx.socketFactory
            hostnameVerifier = javax.net.ssl.HostnameVerifier { _, _ -> true } // identity = pinned fingerprint
            requestMethod = "POST"; doOutput = true
            connectTimeout = 8000; readTimeout = 15000
            setRequestProperty("Content-Type", "application/json")
            headers.forEach { (k, v) -> setRequestProperty(k, v) }
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.readText().orEmpty()
            return Triple(code, text, tm.seen)
        } finally { conn.disconnect() }
    }

    /** Pairs with the agent using the one-time code shown on the laptop. Returns the certificate fingerprint. */
    suspend fun pair(host: String, port: Int, code: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().put("code", code.trim()).put("device_id", store.deviceId).put("name", Build.MODEL ?: "Android")
        val (status, text, fp) = post(host.trim(), port, "/pair", body, emptyMap(), null)
        if (status != 200) throw Exception(parseMsg(text).ifEmpty { "Pairing failed ($status)." })
        val secret = JSONObject(text).getString("secret")
        store.remoteHost = host; store.remotePort = port; store.remoteSecret = secret; store.remoteFingerprint = fp
        fp
    }

    fun unpair() { store.remoteSecret = ""; store.remoteFingerprint = "" }

    suspend fun command(action: String, args: JSONObject = JSONObject()): Reply = withContext(Dispatchers.IO) {
        if (!isPaired()) return@withContext Reply(false, "Laptop isn't paired yet.")
        try {
            val body = JSONObject().put("action", action).put("args", args)
            val h = mapOf("X-Device-Id" to store.deviceId, "X-Device-Secret" to store.remoteSecret)
            val (status, text, _) = post(store.remoteHost, store.remotePort, "/command", body, h, store.remoteFingerprint)
            when (status) {
                200 -> Reply(true, parseMsg(text))
                401, 403 -> Reply(false, parseMsg(text).ifEmpty { "The laptop refused this device. It may have been revoked." })
                else -> Reply(false, parseMsg(text).ifEmpty { "Laptop error ($status)." })
            }
        } catch (e: java.net.SocketTimeoutException) {
            Reply(false, "Your laptop didn't answer. It may be off, asleep, or not on the VPN.")
        } catch (e: java.net.ConnectException) {
            Reply(false, "Can't reach the laptop. Check that the TUS agent is running and your VPN (Tailscale) is on.")
        } catch (e: java.net.UnknownHostException) {
            Reply(false, "Can't find the laptop address. Check the VPN and the host name.")
        } catch (e: Exception) {
            Reply(false, e.message ?: "Remote error.")
        }
    }

    private fun parseMsg(t: String) = try { JSONObject(t).optString("message") } catch (e: Exception) { "" }
}
