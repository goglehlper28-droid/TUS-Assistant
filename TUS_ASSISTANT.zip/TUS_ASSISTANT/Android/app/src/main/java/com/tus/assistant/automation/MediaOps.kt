package com.tus.assistant.automation

import android.content.Context
import android.content.Intent
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Camera photo/video via the stock Camera app (no raw camera access), and simple audio recording. */
object MediaOps {
    private var recorder: MediaRecorder? = null
    private var recordingFile: File? = null

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    private fun mediaDir(ctx: Context): File = ctx.getExternalFilesDir(null)?.also { it.mkdirs() } ?: ctx.filesDir
    private fun uriFor(ctx: Context, f: File): Uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)

    fun takePhoto(ctx: Context): String {
        val f = File(mediaDir(ctx), "photo_${stamp()}.jpg")
        val uri = uriFor(ctx, f)
        val i = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).putExtra(android.provider.MediaStore.EXTRA_OUTPUT, uri)
            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (i.resolveActivity(ctx.packageManager) == null) return "No camera app found."
        ctx.startActivity(i)
        return "Opening the camera. The photo will save automatically; tell me \"where's my last photo\" after."
    }

    fun recordVideo(ctx: Context): String {
        val f = File(mediaDir(ctx), "video_${stamp()}.mp4")
        val uri = uriFor(ctx, f)
        val i = Intent(android.provider.MediaStore.ACTION_VIDEO_CAPTURE).putExtra(android.provider.MediaStore.EXTRA_OUTPUT, uri)
            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (i.resolveActivity(ctx.packageManager) == null) return "No camera app found."
        ctx.startActivity(i)
        return "Opening the camera for video."
    }

    fun startAudio(ctx: Context): String {
        if (recorder != null) return "Already recording. Say \"stop recording\" first."
        return try {
            val f = File(mediaDir(ctx), "audio_${stamp()}.m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOutputFile(f.absolutePath)
            r.prepare(); r.start()
            recorder = r; recordingFile = f
            "Recording audio. Say \"stop recording\" when done."
        } catch (e: Exception) { "I couldn't start recording: ${e.message}" }
    }

    fun stopAudio(): String {
        val r = recorder ?: return "I'm not recording right now."
        return try {
            r.stop(); r.release(); recorder = null
            "Saved as ${recordingFile?.name}."
        } catch (e: Exception) { recorder = null; "Recording stopped, but saving had a problem." }
    }

    fun lastFile(ctx: Context, kind: String): String {
        val files = mediaDir(ctx).listFiles { f -> f.name.startsWith(kind) }?.sortedByDescending { it.lastModified() }
        return if (files.isNullOrEmpty()) "I don't have any $kind yet." else "Last $kind: ${files.first().name}."
    }
}
