package com.tus.assistant.automation

import android.content.ContentValues
import android.content.Context
import android.provider.ContactsContract

/** Create/delete contacts with WRITE_CONTACTS permission, which the user grants and can revoke anytime. */
object ContactOps {
    fun create(ctx: Context, name: String, number: String): String {
        if (ctx.checkSelfPermission(android.Manifest.permission.WRITE_CONTACTS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            return "I need contacts permission. Settings → Phone permissions → Grant call, SMS and contacts."
        return try {
            val raw = ctx.contentResolver.insert(ContactsContract.RawContacts.CONTENT_URI, ContentValues())
                ?: return "Couldn't create the contact."
            val rawId = android.content.ContentUris.parseId(raw)
            ctx.contentResolver.insert(ContactsContract.Data.CONTENT_URI, ContentValues().apply {
                put(ContactsContract.Data.RAW_CONTACT_ID, rawId)
                put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                put(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name)
            })
            ctx.contentResolver.insert(ContactsContract.Data.CONTENT_URI, ContentValues().apply {
                put(ContactsContract.Data.RAW_CONTACT_ID, rawId)
                put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                put(ContactsContract.CommonDataKinds.Phone.NUMBER, number)
                put(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
            })
            "Saved $name as a contact."
        } catch (e: Exception) { "Couldn't create the contact: ${e.message}" }
    }

    fun delete(ctx: Context, name: String): String {
        if (ctx.checkSelfPermission(android.Manifest.permission.WRITE_CONTACTS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            return "I need contacts permission. Settings → Phone permissions → Grant call, SMS and contacts."
        return try {
            val c = ctx.contentResolver.query(ContactsContract.Contacts.CONTENT_URI,
                arrayOf(ContactsContract.Contacts._ID), "${ContactsContract.Contacts.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)
            var deleted = 0
            c?.use { cur -> while (cur.moveToNext()) {
                val id = cur.getLong(0)
                ctx.contentResolver.delete(ContactsContract.RawContacts.CONTENT_URI, "${ContactsContract.RawContacts.CONTACT_ID} = ?", arrayOf(id.toString()))
                deleted++
            } }
            if (deleted == 0) "No contact found matching \"$name\"." else "Deleted $deleted contact(s) matching \"$name\"."
        } catch (e: Exception) { "Couldn't delete: ${e.message}" }
    }
}
