# TUS Assistant (Farid Ghani's personal assistant) — Android + Windows

## Build without installing anything (GitHub, free)
1. Make a free GitHub account, create a new repository (any name).
2. Upload `TUS_ASSISTANT.zip` (Add file → Upload files). Don't unzip it.
3. Add file → Create new file → name it `.github/workflows/build.yml` → paste `Build/build.yml` → Commit.
4. Open the Actions tab → "Build TUS" → wait ~6–10 min. Download `TUS-Android-APK` and `TUS-Windows-EXE` from the run page.
5. If a job fails, open it, copy the red error lines and send them to Claude.

The APK is debug-signed, so it installs on your TECNO directly (allow "install unknown apps"). Play-Store style release signing needs your own keystore (Android Studio or `keytool`), which I can't create for you.

## Feature status
Working (needs your setup): Gemini chat with streaming, voice in/out, 6 languages for speech (depends on languages installed on the phone),
holographic animated face (stylised vector, not photorealistic; mouth movement is simulated, Android TTS gives no audio levels),
phone commands (open apps/sites/settings, dial after confirmation, prepare SMS, WhatsApp share, YouTube, timers, notes, time/date, battery, connectivity, media keys),
encrypted key storage, PIN, view/edit/delete memory and notes, secure laptop pairing (pinned TLS, per-device secret, revocation, audit log), Windows agent with fixed action list.
Interim: wake phrases use looped speech recognition, NOT a keyword-spotting engine (more battery, may beep). True sherpa-onnx wake word is not included.
Not included: biometric unlock, Wake-on-LAN, Windows keyboard/mouse automation, Windows microphone input, reading/managing arbitrary files, notification management, auto language detection (set it in Settings), Pashto/Farsi quality depends on the phone's engine.

## Laptop link
Install Tailscale on phone and laptop (same account). Run TUS_Agent.exe, allow it on Private networks only in the Windows firewall.
Click "Pair new phone"; on the phone: Settings → Laptop link → address (Tailscale IP shown), port, code → Pair. Compare the fingerprint on both screens.
Then say: "check my laptop", "lock my laptop" (asks PIN), "open notepad on my laptop", "note buy milk on my laptop".
Remote actions allowed are listed in `%APPDATA%\TUS\config.json` (allowed_actions). Logs: `%APPDATA%\TUS\audit.log`.

## Security notes
No API keys in code. Phone secrets use Android Keystore-backed encrypted prefs; Windows key uses Credential Manager. No shell access remotely; only fixed actions.
Never port-forward the agent to the internet. Use Tailscale.
