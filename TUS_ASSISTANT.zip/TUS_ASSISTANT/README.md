# TUS Assistant (Farid Ghani's personal assistant) — Android + Windows

## Build without installing anything (GitHub, free)
1. Make a free GitHub account, create a new repository (any name).
2. Upload `TUS_ASSISTANT.zip` (Add file → Upload files). Don't unzip it.
3. Add file → Create new file → name it `.github/workflows/build.yml` → paste `Build/build.yml` → Commit.
4. Open the Actions tab → "Build TUS" → wait ~6–10 min. Download `TUS-Android-APK` and `TUS-Windows-EXE` from the run page.
5. If a job fails, open it, copy the red error lines and send them to Claude.

The APK is debug-signed, so it installs on your TECNO directly (allow "install unknown apps"). Play-Store style release signing needs your own keystore (Android Studio or `keytool`), which I can't create for you.

## Feature status
Working (needs your setup): Gemini chat with streaming, voice in/out, 6 languages for speech (depends on languages installed on the phone),
holographic animated face (stylised vector, not photorealistic; mouth movement is simulated, Android TTS gives no audio levels),
phone commands (open apps/sites/settings, dial after confirmation, prepare SMS, WhatsApp share, YouTube, timers, notes, time/date, battery, connectivity, media keys),
encrypted key storage, PIN, view/edit/delete memory and notes, secure laptop pairing (pinned TLS, per-device secret, revocation, audit log), Windows agent with fixed action list.
Interim: wake phrases use looped speech recognition, NOT a keyword-spotting engine (more battery, may beep). True sherpa-onnx wake word is not included.
Not included: biometric unlock, Wake-on-LAN, Windows keyboard/mouse automation, Windows microphone input, reading/managing arbitrary files, notification management, auto language detection (set it in Settings), Pashto/Farsi quality depends on the phone's engine.

## Laptop link
Install Tailscale on phone and laptop (same account). Run TUS_Agent.exe, allow it on Private networks only in the Windows firewall.
Click "Pair new phone"; on the phone: Settings → Laptop link → address (Tailscale IP shown), port, code → Pair. Compare the fingerprint on both screens.
Then say: "check my laptop", "lock my laptop" (asks PIN), "open notepad on my laptop", "note buy milk on my laptop".
Remote actions allowed are listed in `%APPDATA%\TUS\config.json` (allowed_actions). Logs: `%APPDATA%\TUS\audit.log`.

## Security notes
No API keys in code. Phone secrets use Android Keystore-backed encrypted prefs; Windows key uses Credential Manager. No shell access remotely; only fixed actions.
Never port-forward the agent to the internet. Use Tailscale.


## Version 3 additions
- Natural human voice: Gemini TTS (voice "Charon", editable in Settings → Voice quality). Falls back to Android's voice if the API fails. Needs internet and your API key.
- Phone control by voice/text: back, home, recents, notifications, screenshot, lock screen, scroll, "click <text>", "type <text>", "read screen" (needs Accessibility switched on by you); read/clear notifications (needs notification access); call/SMS by contact name; flashlight; volume.
- Laptop control: open any app, browser/website, type text, press keys, click, move mouse, volume, media keys, find files (Documents/Desktop/Downloads), run YOUR scripts from %APPDATA%\TUS\scripts, shutdown/restart/sleep (PIN), lock (PIN).
- Background: foreground service + wake lock. Wake phrases are still looped speech recognition, not a keyword engine.
- Android 13+ blocks Accessibility/Notification access for apps installed from a file until: App info → ⋮ → Allow restricted settings.
- Not possible: bypassing lock screen/PIN/permissions, unlocking the laptop, unrestricted shell access (by design).

## Version 4 additions
- Fingerprint confirmation for sensitive actions (alongside PIN).
- Phone files: choose one folder in Settings; then "list files", "find file X", "read file X", "create file X with ...", "delete file X" (asks first). TUS can only touch that folder.
- Wake-on-LAN: "wake my laptop" (phone must be on the same Wi-Fi/LAN; laptop needs WoL enabled in BIOS/network card; most Wi-Fi-only laptops can't).
- Windows: "Speak" button records from the microphone only while pressed, then Gemini turns it into text.
- Language: set "auto" in Settings to match your phone's language for listening, and replies speak in the language detected from the text (Urdu/Hindi/English).
- Still NOT included: real keyword-spotting wake word (sherpa-onnx), laptop-to-phone commands, Windows keyboard/mouse "approved workflows" beyond the actions listed.

## Version 5 additions (now named "F.G")
- App display name changed to "F.G"; it always says it's Farid's AI assistant, never pretends to be Farid.
- Web search grounding: Gemini can search the web for current answers (Settings → toggle off if not wanted).
- SMS auto-reply (off by default): when you're away, replies to texts with Gemini, ALWAYS tagged "[F.G, Farid's AI assistant]" so the sender is never deceived. Turn on in Settings; needs SMS and contacts permission.
- Camera: "take a photo", "record a video" (opens the stock camera app; files save to the app's own folder; "where's my last photo/video/audio").
- Audio: "record audio" / "stop recording".
- Contacts: "add contact NAME number 03xxxxxxxxx" (confirm), "delete contact NAME" (confirm).
- Apps: "install X" opens Play Store search (you tap Install — Android never allows silent installs); "uninstall X" shows Android's own uninstall confirmation screen (can't be skipped).
- Declined by design: silently impersonating Farid to someone else, disabling/bypassing Google Play Protect, and silent app install/uninstall without your on-screen confirmation. These either deceive people or remove real security protections.
